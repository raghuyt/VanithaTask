# FSWWDT — Fail-Safe Window Watchdog Timer
## Design Specification, Verification Plan and Cadence Flow

Version 1.0 draft. Status: RTL and UVM environment written, **not yet compiled or simulated**. All Cadence tool commands in this document must be checked against the documentation of the installed Xcelium / IMC / vManager release.

---

## 1. Project understanding

### 1.1 What the block does
A watchdog timer detects that software (or the system executing it) has stopped behaving correctly and forces recovery. Firmware must periodically "kick" (refresh) the watchdog. If it does not, the watchdog assumes the system is hung and requests a reset.

A **window** watchdog adds a lower bound: kicking *too early* is also a fault. This catches runaway code that sits in a tight loop repeatedly kicking the watchdog, which a simple timeout watchdog cannot detect.

**Fail-safe** means that any failure of the watchdog's own environment drives it towards the safe outcome (reset), never towards silently doing nothing:

| Failure | Consequence without fail-safe design | FSWWDT behaviour |
|---|---|---|
| CPU hangs | no kicks | timeout → reset |
| Runaway kick loop | continuous kicks | early-kick fault → reset |
| Corrupted kick write | wrong data | key check → fault |
| Bus clock (pclk) stops | software dead, watchdog must still act | core runs on independent wdt_clk → timeout → reset |
| Watchdog clock stops | counter frozen forever | clock monitor in pclk domain → CLK_FAIL → reset |
| Counter flop upset (SEU) | wrong expiry time | redundant inverted counter → mismatch fault |
| FSM corrupted to illegal code | stuck | illegal state recovers to BITE |
| Software disables watchdog by mistake | protection lost | LOCK bit (sticky until reset) |

### 1.2 Typical use cases
- Automotive / industrial MCU software supervision (ISO 26262 / IEC 61508 style safety mechanism).
- Boot supervision: enable early, locked, before loading an OS.
- Task-level liveness: the kick is placed at the end of a periodic control loop; the window enforces that the loop is neither stalled nor running abnormally fast.
- Early-warning interrupt (EWI) lets software log state or attempt graceful recovery before the hard reset.

### 1.3 Interfaces

| Port | Dir | Domain | Description |
|---|---|---|---|
| pclk | in | — | APB bus clock |
| presetn | in | async | active-low system reset (synchronized internally per domain) |
| psel, penable, pwrite, paddr[11:0], pwdata[31:0] | in | pclk | APB3 slave |
| prdata[31:0], pready, pslverr | out | pclk | APB3 slave response (pready tied 1) |
| wdt_clk | in | — | independent always-on watchdog clock |
| scan_mode_i | in | static | bypasses reset synchronizers in scan |
| dbg_halt_i | in | async | CPU halted by debugger |
| wdt_irq_o | out | pclk | level interrupt = OR of enabled STATUS flags |
| wdt_rst_req_o | out | async | reset request to SoC reset controller (must be synchronized there) |

Parameters: `RST_LEN` (reset request length in wdt_clk cycles, default 16), `CLKMON_LIMIT` (pclk cycles without a wdt heartbeat before CLK_FAIL, default 64), `SYNC_STAGES` (default 2).

---

## 2. Design specification

### 2.1 Block diagram

```
                 pclk domain                          |         wdt_clk domain
  APB  ──► ┌──────────────────────┐   cfg bundle      |
           │  fswwdt_apb_regs     │ ──► hs_sync ──────┼──► cfg_w ──┐
           │  CTRL TIMEOUT WINDOW │   kick(+bad bit)  |            ▼
           │  EWI KICK STATUS     │ ──► hs_sync ──────┼──► ┌───────────────────┐
           │  IRQ_EN COUNT FI ID  │                   |    │   fswwdt_core     │
           │  flags, PSLVERR rules│ ◄── evt_sync ◄────┼─── │ counter + shadow  │
           │                      │ ◄── hs_sync  ◄────┼─── │ window FSM        │──► core_rst_req
           └──────┬───────────────┘  {state,count}    |    │ fault detection   │
                  │ irq                                |    └────────┬──────────┘
                  ▼                                    |             │ heartbeat
            wdt_irq_o      ┌──────────────┐  sync_cell|             │
                           │ fswwdt_clk_mon│ ◄─────────┼─────────────┘
                           └──────┬───────┘  dbg_halt ─┼──► sync_cell ──► core
                                  │ clkfail_rst        |
                                  └────────── OR ◄─────┴──── core_rst_req ──► wdt_rst_req_o
        presetn ──► rst_sync(pclk) ──► prst_n          presetn ──► rst_sync(wdt_clk) ──► wrst_n
```

### 2.2 Hierarchy

```
fswwdt_top
├── u_prst_sync   fswwdt_rst_sync     (pclk)
├── u_wrst_sync   fswwdt_rst_sync     (wdt_clk)
├── u_regs        fswwdt_apb_regs     (pclk)
├── u_cfg_sync    fswwdt_hs_sync      pclk → wdt   (W = CFG_W)
├── u_kick_sync   fswwdt_hs_sync      pclk → wdt   (W = 1, data = bad-key bit)
├── u_evt_sync    fswwdt_evt_sync     wdt → pclk   (coalescing event pulses)
├── u_snap_sync   fswwdt_hs_sync      wdt → pclk   ({state, count}, free-running)
├── u_dbg_sync    fswwdt_sync_cell    → wdt
├── u_hb_sync     fswwdt_sync_cell    → pclk
├── u_clk_mon     fswwdt_clk_mon      (pclk)
└── u_core        fswwdt_core         (wdt_clk)
```

### 2.3 Clocking strategy
- **Why two clocks:** a watchdog clocked by the bus clock dies with the bus clock. The core is on an independent, always-on clock (typically an RC oscillator in silicon); the register file stays on pclk so software sees normal zero-wait APB timing.
- **Why a clock monitor:** the core cannot detect its own clock stopping. The core toggles a heartbeat every wdt_clk cycle; the pclk-domain monitor raises CLK_FAIL if no edge arrives for `CLKMON_LIMIT` pclk cycles while enabled. Requirement: f_pclk ≥ ~4 × f_wdt, and `CLKMON_LIMIT` must exceed the longest legal heartbeat gap in pclk cycles with margin.
- **CDC scheme:**
  - Multi-bit configuration: request/acknowledge toggle handshake with data held stable in the source (no multi-bit synchronizers on data). Asserted in sim by `a_src_data_stable` in `fswwdt_hs_sync`.
  - Configuration writes are **rejected (PSLVERR) while CFG_PEND**. This is a deliberate simplification: every accepted configuration reaches the core in order and atomically, and the core never sees partial updates. Firmware polls STATUS.CFG_PEND.
  - Kick: same handshake, one kick in flight; a second kick while KICK_PEND is rejected, so kicks are never silently merged.
  - Events wdt → pclk: coalescing toggle synchronizer; STATUS flags are sticky so coalescing never loses a *flag*, only the count of occurrences.
  - COUNT/STATE snapshot: continuous handshake, so reads are consistent but lag by a few cycles (documented as approximate).
  - Level signals (dbg_halt, heartbeat): 2-flop synchronizer cells, one place to swap in library sync cells.

### 2.4 Reset strategy
- One external async reset `presetn`, synchronized separately into each domain: asynchronous assertion (works with a stopped clock), synchronous de-assertion (no recovery/removal violations). `scan_mode_i` bypasses the synchronizer for test.
- All state is reset: after any reset the watchdog is DISABLED, unlocked, flags clear, TIMEOUT = 0xFFFF.
- `wdt_rst_req_o` is the OR of a wdt-domain flop and a pclk-domain flop and is therefore asynchronous to both; the SoC reset controller must synchronize it. Reset-cause storage belongs in the reset controller (out of scope).

### 2.5 Register map (base + offset, 32-bit, word aligned)

| Off | Name | Access | Reset | Fields |
|---|---|---|---|---|
| 0x00 | CTRL | RW | 0 | [0] EN, [1] WIN_EN, [2] RST_EN, [3] DBG_FRZ, [31] LOCK (W1S, sticky until reset) |
| 0x04 | TIMEOUT | RW | 0x0000_FFFF | expiry count in wdt_clk cycles (≠0) |
| 0x08 | WINDOW | RW | 0 | closed-window length; kicks while count < WINDOW are faults |
| 0x0C | EWI | RW | 0 | early-warning count (0 = off), must be < TIMEOUT |
| 0x10 | KICK | WO | — | write 0xA5A5_5A5A to refresh; any other value = key fault; reads 0 |
| 0x14 | STATUS | W1C/RO | 0 | [0] EWI [1] TMO [2] EARLY [3] KEYERR [4] CNTERR [5] CLKFAIL (W1C); [8] KICK_PEND [9] CFG_PEND [10] LOCKED [14:12] STATE (RO) |
| 0x18 | IRQ_EN | RW | 0 | [5:0] interrupt enable per flag (always writable, even locked) |
| 0x1C | COUNT | RO | 0 | current count (synchronized snapshot, approximate) |
| 0x20 | FAULT_INJ | RW | 0 | [0] rising edge corrupts shadow counter once (safety-mechanism self test) |
| 0x24 | ID | RO | 0x4657_0100 | "FW" v1.0 |

**PSLVERR rules** (write is ignored when PSLVERR=1):
1. unmapped or misaligned address (read or write);
2. write to COUNT or ID;
3. LOCK=1 and write to CTRL/TIMEOUT/WINDOW/EWI/FAULT_INJ;
4. write to TIMEOUT/WINDOW/EWI while EN=1;
5. write CTRL with EN=1 and an illegal configuration: TIMEOUT=0, or WIN_EN and WINDOW ≥ TIMEOUT, or EWI ≥ TIMEOUT;
6. changing WIN_EN while EN=1;
7. any configuration write while CFG_PEND;
8. KICK write while KICK_PEND.

Rationale: an error response is always better than silently accepting a write that would put the watchdog in an undefined or weakened state.

### 2.6 Core FSM

```
            EN=1, win_en & window≠0            count+1 ≥ WINDOW
  ┌──────────┐ ─────────────────────► ┌────────┐ ───────────────► ┌──────┐
  │ DISABLED │                        │ CLOSED │                  │ OPEN │
  └──────────┘ ◄──── EN=0 ─────────── └────────┘ ◄── good kick ── └──────┘
       ▲  EN=1, no window ───────────────────────────────────────►   │
       │                 fault & RST_EN=0 → restart (CLOSED/OPEN)     │
       │                 fault & RST_EN=1 ──────────┐                  │
       │                                            ▼                  │
       │   system reset        ┌──────┐  RST_LEN   ┌──────┐ ◄──────────┘
       └────────────────────── │ HALT │ ◄───────── │ BITE │   (fault)
                               └──────┘  cycles    └──────┘
                     illegal state code ──────────────► BITE
```

| State | Code | Counter | Kick | wdt_rst_req |
|---|---|---|---|---|
| DISABLED | 0 | held 0 | ignored | 0 |
| CLOSED | 1 | counting | EARLY fault | 0 |
| OPEN | 2 | counting | reload, go to CLOSED/OPEN | 0 |
| BITE | 3 | 0 | ignored | 1 for RST_LEN cycles |
| HALT | 4 | 0 | ignored | 0, waits for reset |

Priority inside a running cycle: **fault > disable > kick > tick**. A fault in the same cycle as a disable still bites. This prevents "disable at the last moment" masking a fault.

Timeout detection: fault when `count + 1 == TIMEOUT`, i.e. exactly TIMEOUT ticks after (re)start. EWI event when `count + 1 == EWI`. DBG_FRZ & dbg_halt stops ticks (counter holds, no heartbeat stop).

### 2.7 RTL coding choices (Cadence / synthesis friendly)
- `always_ff` with async active-low reset, `always_comb` next-state logic, all defaults assigned at the top of combinational blocks (no latches).
- Enumerated state type in a package, packed struct for the configuration bundle (one width, one place).
- `cfg_legal()` function shared by RTL and testbench predictor so the rule cannot diverge.
- No initial blocks, no delays, no `casex`, no inferred multi-bit synchronizers.
- **Synthesis must be told** to preserve the shadow counter (it is logically redundant and would be optimized away) and the illegal-state recovery (FSM extraction may drop the default branch). Use the synthesis tool's preserve / safe-FSM directives in constraints, not in RTL.

---

## 3. Verification architecture

```
 tb_top
 ├── clk_rst_if  (clock generators with run-time period/stop, async & sync reset tasks,
 │                reset-controller model counters, dbg_halt, scan_mode)
 ├── apb_if ───────────────┐              ┌───────── wdt_probe_if (white-box, wdt_clk)
 ├── DUT fswwdt_top        │              │
 │     + bound SVA         │              │
 └── uvm_test_top          │              │
     └── env               │              │
         ├── apb_agt  (drv, sqr, mon) ────┘              prb_agt (mon) ──┐
         │        │ apb_seq_item                                         │ wdt_core_txn
         ├── sb ◄─┴── check1 register predictor (rdata + PSLVERR exact)  │
         │        ◄── check2 cycle-accurate core model vs probe  ◄───────┤
         │            check3 config delivery order across CDC            │
         │            check4 kick accounting (no lost/duplicate kicks)   │
         │            check5 STATUS flags: no spurious, none missing     │
         └── cov  ◄── cg_reg cg_ctrl cg_cfg cg_fsm cg_fault cg_kick cg_reset cg_dbg
```

Design decisions:
- **White-box probing of the core** lets the scoreboard run a cycle-accurate model instead of inferring state through the lagging COUNT snapshot. Trade-off: probe paths couple the TB to RTL names; they are isolated in `tb_top.sv` only.
- **Sequences are written as a firmware driver API** (`configure`, `enable`, `kick_in_window`, `wait_flag`, `expect_wdt_reset`), so tests read like the software that will use the IP and polling handles CDC latency naturally.
- **Checking is independent of stimulus**: every test is self-checking through scoreboard and SVA, even random ones.
- **Reset-controller model** in tb_top reacts to `wdt_rst_req_o` with a wall-clock timed reset, so reset scenarios work even with a stopped clock. Tests can disable it (`auto_reset_en`) to own the reset.
- The APB driver aborts an in-flight transfer on reset and marks it `aborted`; the predictor ignores aborted items.

Known limitation: the reference model is written from the same spec as the RTL. A spec misunderstanding would be shared. Mitigations: SVA written as independent properties, directed tests with explicit expectations, and spec review with the architect.

---

## 4. Test plan

### 4.1 Functional tests

| ID | Feature | Test | Checks |
|---|---|---|---|
| TP-REG-01 | reset values | reg_access | predictor on every register |
| TP-REG-02 | RW patterns | reg_access | walking 1s, 0/F/A5/5A on TIMEOUT/WINDOW/EWI/IRQ_EN |
| TP-REG-03 | RO/unmapped/misaligned | reg_access | PSLVERR, no side effects (SVA a_err_no_update) |
| TP-REG-04 | enable with illegal cfg | reg_access, rand | PSLVERR rule 5 |
| TP-REG-05 | cfg while running / pending | reg_access, rand | PSLVERR rules 4, 6, 7 |
| TP-BASIC-01 | enable, count, disable | timeout, window | model vs probe |
| TP-TMO-01 | timeout with RST_EN=1 | timeout | reset request, RST_LEN, HALT |
| TP-TMO-02 | timeout with RST_EN=0 | timeout | TMO flag, period restarts |
| TP-WIN-01 | kicks in open window | window | no fault, no reset |
| TP-WIN-02 | window disabled | window | kick at any time is OK |
| TP-EARLY-01 | kick in closed window | early_kick | EARLY flag / reset |
| TP-LATE-01 | kick after expiry | late_kick | TMO already raised, late kick harmless |
| TP-KEY-01 | wrong key disabled/enabled | bad_key | KEYERR always; fault only when running |
| TP-IRQ-01 | EWI interrupt service loop | ewi_irq | irq asserts, W1C deasserts, kick in ISR |
| TP-IRQ-02 | IRQ_EN masking | rand | SVA a_irq_follow |
| TP-LOCK-01 | lock and locked writes | lock | PSLVERR, IRQ_EN writable, lock cleared by reset |
| TP-FI-01 | shadow counter fault injection | fault_inj | CNTERR / reset |
| TP-DBG-01 | debug freeze on/off | dbg_freeze | no timeout when frozen, timeout when not |
| TP-CFG-01 | extreme configs (TIMEOUT 1..3, 2^32-1, window 0–90 %) | cfg_corner | cg_cfg crosses |
| TP-RAND-01 | random mix | random | all scoreboard checks |

### 4.2 Clock and reset tests

| ID | Scenario | Test | Expected |
|---|---|---|---|
| TP-RST-01 | power-on reset | every test (base) | all reset values, DISABLED |
| TP-RST-02 | warm reset with clocks running | clk_ratio, reset_during_run | clean restart |
| TP-RST-03 | async reset at arbitrary time | reset_during_run (sync_rst=0) | no X, clean state, SVA silent |
| TP-RST-04 | sync (pclk-aligned) reset | reset_during_run (sync_rst=1) | same |
| TP-RST-05 | reset during operation, locked or not | reset_during_run | LOCK and flags cleared |
| TP-RST-06 | reset at timeout detection | reset_during_bite AT_TIMEOUT | either restarts cleanly or bites; never a stuck request |
| TP-RST-07 | reset in BITE and in HALT | reset_during_bite | request drops, DISABLED |
| TP-CLK-01 | wdt_clk stop, RST_EN=0 | clk_fail | CLK_FAIL flag, no reset |
| TP-CLK-02 | wdt_clk stop, RST_EN=1, then restart | clk_fail | reset request from clock monitor; recovery |
| TP-CLK-03 | pclk stop | pclk_stop | core times out and resets |
| TP-CLK-04 | clock ratio sweep 4 / 8 / 20 / 40 | clk_ratio | same behaviour at every ratio |
| TP-CLK-05 | frequency change while running | clk_freq_change | no fault, no reset |

Not covered in simulation (planned for formal / static tools): illegal FSM codes (Jasper FPV with a free state variable or a force-based directed test with the state assertion disabled), metastability effects (CDC tool + optionally Xcelium metastability injection if licensed), glitches on async reset.

---

## 5. Functional coverage

| Covergroup | Content | Key crosses |
|---|---|---|
| cg_reg | address × direction × PSLVERR | illegal combos ignored (e.g. RO write OK) |
| cg_ctrl | every CTRL bit written 0/1 | — |
| cg_cfg (sampled at enable) | TIMEOUT tiny/small/mid/large/max, window % 0/low/mid/high, WIN_EN, EWI on/off, clock ratio | window % × timeout, EWI × WIN_EN |
| cg_fsm | every state, every legal transition, full-period sequence | — |
| cg_fault | kind (TMO/EARLY/KEY/CNTERR) × state × RST_EN | early-in-open ignored |
| cg_kick | good/early/bad/ignored × WIN_EN | — |
| cg_reset | reset in each FSM state | — |
| cg_dbg | frozen in CLOSED/OPEN | — |
| SVA covers | e.g. kick on last legal cycle, fault and kick same cycle, EWI then kick | — |

Excluded bins are documented at the point of exclusion (e.g. clock ratio < 4 is outside the operating spec; window-% bins unreachable when TIMEOUT ≤ 3).

**Targets (typical industry values; agree the exact numbers with your project / safety lead):**
functional coverage 100 % (with reviewed exclusions), assertion pass/cover 100 %, code block ≥ 98 %, expression ≥ 95 %, toggle ≥ 90 %, FSM state and arc 100 %. Every code-coverage hole must be closed with a test or a reviewed, signed exclusion.

**Closure strategy:**
1. Run directed tests first — they close most bins cheaply.
2. Run random tests with many seeds; rank tests by coverage contribution (IMC ranking) to size the nightly regression.
3. For remaining holes: analyse whether reachable. Reachable → add constraints or a directed test. Unreachable → exclusion with written justification (feeds back into the spec if it reveals a gap).
4. Freeze the exclusion file under review; re-run the full regression at every RTL change.

---

## 6. Assertions (SVA)

Located in `tb/sva/`, bound with `fswwdt_bind.sv` so RTL files stay synthesis-clean. `fswwdt_hs_sync` also contains an in-RTL assertion under `` `ifdef FSWWDT_ASSERT_ON``.

| Area | Examples |
|---|---|
| Timeout | a_cnt_start, a_cnt_inc, a_cnt_hold, a_cnt_bound, a_tmo_at_limit, a_tmo_not_miss (together prove exact expiry by induction) |
| Window | a_closed_inv, a_open_inv, a_early_fault, a_kick_reload |
| Interrupt / events | a_tmo_event, a_ewi_event, a_early_event, a_irq_follow, per-flag sticky assertions |
| Reset generation | a_rst_is_bite, a_rst_len (exactly RST_LEN), a_rst_cause, a_halt_sticky, a_no_rst_dis |
| Register protocol | APB setup→access, stability, single-cycle access, PSLVERR rules 1–5 & 8, a_err_no_update, a_lock_sticky, a_locked_stable |
| Error handling | a_key_fault, a_fi_detect, a_fault_bite, a_fault_restart, a_fault_prio, a_clkfail_rst |
| CDC | a_src_data_stable (source data held while a handshake is in flight) |

The core assertions are also directly reusable in Jasper FPV, where they can be proven rather than just checked.

---

## 7. Cadence flow

All commands are examples. **Verify every option against your release** (`xrun -helpall`, IMC and vManager docs).

```bash
cd sim
make compile                                   # xrun ... -elaborate  (one snapshot)
make sim TEST=fswwdt_window_test SEED=7        # xrun -R ... +UVM_TESTNAME -svseed
make sim TEST=fswwdt_timeout_test WAVES=1      # adds -input scripts/waves.tcl (SHM)
make gui TEST=fswwdt_lock_test                 # SimVision interactive
make regress JOBS=8                            # regress/regress.sh + coverage merge
make cov_gui                                   # imc on merged database
```

Representative underlying command (single step, for reference):
```bash
xrun -64bit -sv -uvm -uvmhome CDNS-1.2 -timescale 1ns/1ps \
     -access +rwc -linedebug +define+FSWWDT_ASSERT_ON \
     -f rtl.f -f tb.f -top tb_top \
     +UVM_TESTNAME=fswwdt_window_test -svseed 7 \
     -coverage all -covfile scripts/cov.ccf -covdut fswwdt_top \
     -covworkdir cov_work -covscope fswwdt -covtest window_7 -covoverwrite \
     -l sim.log
```

Debug tips:
- `-access +rwc` is needed for waveform probing and SimVision; it costs speed, so regressions can drop to `+r` or none.
- In SimVision, send `u_dut.u_core` and `u_dut.u_regs` to the waveform together with the probe interface; the scoreboard messages print the wdt_clk cycle at which the model diverged.
- Assertion failures are listed in the SimVision assertion browser; each assertion has a name that maps to a spec rule.
- Reproduce a failing regression run with the same `TEST` and `SEED`; the snapshot is shared, so this takes seconds.

Coverage: code coverage is restricted to the DUT by `-covdut`; `cov.ccf` selects block/expression/toggle/FSM. `scripts/cov_merge.tcl` merges all runs and writes summary, functional and code reports. vManager: `regress/fswwdt.vsif` is a structural example to adapt.

---

## 8. Execution plan — Day 1 to signoff

Indicative for one designer + one verification engineer; adjust to your team.

| Week | Design | Verification | Exit criteria |
|---|---|---|---|
| 1 | Spec review, register map freeze, CDC architecture sign-off | Test plan, coverage plan, TB architecture review | Spec v1.0 approved |
| 2 | RTL all blocks, lint clean (HAL / Conformal lint or equivalent) | Interfaces, agents, env skeleton, smoke test | Smoke test passes |
| 3 | Bug fixes, CDC tool run, synthesis trial with preserve directives | Scoreboard, reference model, SVA, directed tests | All directed tests pass |
| 4 | RTL freeze candidate | Random tests, clock/reset tests, coverage collection | First full regression green |
| 5 | Only bug fixes (change control) | Coverage closure, exclusion review, formal on core (Jasper FPV) | Coverage targets met |
| 6 | Final CDC/RDC sign-off, gate-level smoke sim (optional) | Final regression with fixed seeds + random seeds, sign-off report | Sign-off review passed |

Sign-off checklist: spec/test-plan traceability complete; 0 failing tests in last N nightly regressions; coverage targets met with reviewed exclusions; all assertions pass and all covers hit; lint, CDC and RDC clean or waived with justification; synthesis confirms shadow counter and safe FSM preserved; known limitations documented.

---

## 9. Deliverables

```
fswwdt/
├── docs/FSWWDT_spec_and_plan.md
├── rtl/          fswwdt_pkg, sync_cell, rst_sync, hs_sync, evt_sync,
│                 apb_regs, clk_mon, core, top
├── tb/
│   ├── if/       clk_rst_if, apb_if, wdt_probe_if
│   ├── agents/apb/        seq_item, driver, monitor, agent, pkg
│   ├── agents/wdt_probe/  core_txn, monitor, agent, pkg
│   ├── env/      core_model, reg_predictor, scoreboard, coverage, env, pkg
│   ├── seq/      base_seq, seq_lib, seq_clkrst, pkg
│   ├── tests/    base_test, tests (18), pkg
│   ├── sva/      core_sva, top_sva, bind
│   └── top/      tb_top
└── sim/          rtl.f, tb.f, Makefile,
                  scripts/{waves.tcl, cov.ccf, cov_merge.tcl},
                  regress/{regress.sh, tests.list, fswwdt.vsif}
```

UVM hierarchy:
```
uvm_test_top (fswwdt_*_test)
└── env (fswwdt_env)
    ├── apb_agt (apb_agent)      : drv, sqr, mon
    ├── prb_agt (wdt_probe_agent): mon
    ├── sb  (fswwdt_scoreboard)  : pred (reg predictor), model (core model)
    └── cov (fswwdt_coverage)
```

---

## 10. Best practices applied, and known limitations

Applied: single source of truth for constants (package shared by RTL and TB); legal-config function shared; assertions bound externally; checking separated from stimulus; firmware-style sequence API; every exclusion justified in place; one shared snapshot for fast regressions; greppable PASS/FAIL line; seeds recorded per run.

Known limitations / follow-ups:
1. Code has not been compiled or simulated yet; expect first-compile fixes.
2. TB relies on white-box probes; if RTL signal names change, update `tb_top.sv`.
3. Reference model mirrors the spec (shared-misunderstanding risk) — mitigated by independent SVA and review.
4. COUNT reads are approximate (CDC snapshot lag) — firmware should not use COUNT for exact timing.
5. Synthesis must preserve the shadow counter and safe-FSM recovery — must be checked in the netlist.
6. CDC/RDC sign-off must be done with a structural tool (e.g. Conformal CDC or Jasper CDC); simulation cannot prove CDC correctness.
7. Illegal-state recovery is best proven formally; the simulation TB does not inject illegal states.
8. Reset-cause recording is out of scope (reset controller responsibility).
9. For a certified safety product, the safety analysis (FMEDA, diagnostic coverage figures) is a separate deliverable not covered here.
