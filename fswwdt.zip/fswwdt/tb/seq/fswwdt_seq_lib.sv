//-----------------------------------------------------------------------------
// fswwdt_seq_lib.sv : stimulus sequences (one per test-plan feature)
//-----------------------------------------------------------------------------

// ---------------- TP-REG : register access ---------------------------------
class fswwdt_reg_access_seq extends fswwdt_base_seq;
  `uvm_object_utils(fswwdt_reg_access_seq)
  function new(string name = "fswwdt_reg_access_seq"); super.new(name); endfunction

  task body();
    bit [31:0] d;
    bit [31:0] pats[$] = '{32'h0, 32'hFFFF_FFFF, 32'hA5A5_A5A5, 32'h5A5A_5A5A};
    bit [ADDR_W-1:0] all[$] = '{ADDR_CTRL, ADDR_TIMEOUT, ADDR_WINDOW, ADDR_EWI, ADDR_KICK,
                                ADDR_STATUS, ADDR_IRQ_EN, ADDR_COUNT, ADDR_FAULT_INJ, ADDR_ID};
    for (int i = 0; i < 32; i++) pats.push_back(32'h1 << i);            // walking 1

    // 1. reset values (scoreboard checks data)
    foreach (all[i]) rd(all[i], d);

    // 2. RW patterns on timing registers (EN=0)
    foreach (pats[i]) begin
      wr(ADDR_TIMEOUT, pats[i]); wait_cfg_idle(); rd(ADDR_TIMEOUT, d);
      wr(ADDR_WINDOW,  pats[i]); wait_cfg_idle(); rd(ADDR_WINDOW,  d);
      wr(ADDR_EWI,     pats[i]); wait_cfg_idle(); rd(ADDR_EWI,     d);
      wr(ADDR_IRQ_EN,  pats[i]);                  rd(ADDR_IRQ_EN,  d);
    end
    wr(ADDR_FAULT_INJ, 1); wait_cfg_idle(); rd(ADDR_FAULT_INJ, d);
    wr(ADDR_FAULT_INJ, 0); wait_cfg_idle(); rd(ADDR_FAULT_INJ, d);

    // 3. RO / unmapped / misaligned
    wr(ADDR_COUNT, 32'hDEAD_BEEF); expect_err(1, "write COUNT");
    wr(ADDR_ID,    32'hDEAD_BEEF); expect_err(1, "write ID");
    rd(12'h028, d);                expect_err(1, "read unmapped 0x028");
    wr(12'h100, 32'h1);            expect_err(1, "write unmapped 0x100");
    rd(12'hFFC, d);                expect_err(1, "read unmapped 0xFFC");
    rd(12'h002, d);                expect_err(1, "read misaligned 0x002");
    wr(12'h005, 32'h1);            expect_err(1, "write misaligned 0x005");
    rd(ADDR_KICK, d);              expect_err(0, "read KICK");

    // 4. illegal configurations must be rejected at enable
    configure(0);                     enable(0, 0); expect_err(1, "enable TIMEOUT=0");
    configure(100, 100);              enable(1, 0); expect_err(1, "enable WINDOW>=TIMEOUT");
    configure(100, 100);              enable(0, 0); expect_err(0, "enable WINDOW ignored (WIN_EN=0)");
    wr(ADDR_TIMEOUT, 50);                            expect_err(1, "TIMEOUT write while EN=1");
    wdt_disable();
    configure(100, 10, 100);          enable(1, 0); expect_err(1, "enable EWI>=TIMEOUT");
    configure(100, 10, 0);            enable(1, 0); expect_err(0, "legal enable");
    begin bit [31:0] c = 32'h1;       // EN=1, WIN_EN=0 while running with WIN_EN=1
      wr(ADDR_CTRL, c);               expect_err(1, "WIN_EN change while running"); end
    wdt_disable();

    // 5. timing-dependent PSLVERR (scoreboard predicts from CFG_PEND/KICK_PEND)
    wr(ADDR_TIMEOUT, 32'h200);
    wr(ADDR_WINDOW,  32'h010);     // very likely rejected: CFG_PEND
    wait_cfg_idle();
    wr(ADDR_KICK, KICK_KEY);
    wr(ADDR_KICK, KICK_KEY);       // very likely rejected: KICK_PEND
    wait_kick_idle();

    // 6. restore
    configure(TIMEOUT_RST, 0, 0, '0);
  endtask
endclass

// ---------------- common randomized timing profile -------------------------
class fswwdt_timed_seq extends fswwdt_base_seq;
  `uvm_object_utils(fswwdt_timed_seq)
  rand bit [CNT_W-1:0] timeout, window, ewi;
  rand bit             win_en, rst_en;
  constraint c_to  { timeout inside {[200:600]}; }
  constraint c_win { win_en -> window inside {[16 : timeout/2]}; !win_en -> window == 0; }
  constraint c_ewi { soft ewi == 0; }
  function new(string name = "fswwdt_timed_seq"); super.new(name); endfunction
endclass

// ---------------- TP-BASIC / TP-TMO : no service -> timeout -----------------
class fswwdt_timeout_seq extends fswwdt_timed_seq;
  `uvm_object_utils(fswwdt_timeout_seq)
  function new(string name = "fswwdt_timeout_seq"); super.new(name); endfunction
  task body();
    `uvm_info("SEQ", $sformatf("timeout test: to=%0d win_en=%0b win=%0d rst_en=%0b",
                               timeout, win_en, window, rst_en), UVM_LOW)
    configure(timeout, window);
    enable(win_en, rst_en);
    if (rst_en) begin
      expect_wdt_reset((timeout + 100) * crif.wdt_period());
    end else begin
      wait_flag(FLG_TMO);
      clear_flags();
      wait_flag(FLG_TMO);            // periodic behaviour without reset
      wdt_disable();
    end
  endtask
endclass

// ---------------- TP-WIN : correct servicing, no fault ---------------------
class fswwdt_window_service_seq extends fswwdt_timed_seq;
  `uvm_object_utils(fswwdt_window_service_seq)
  rand int unsigned n_kicks;
  constraint c_n   { n_kicks inside {[3:8]}; }
  constraint c_rst { rst_en == 1; }                 // any fault would reset -> caught
  function new(string name = "fswwdt_window_service_seq"); super.new(name); endfunction
  task body();
    int unsigned r0;
    configure(timeout, window);
    enable(win_en, rst_en);
    r0 = crif.rst_req_count;
    repeat (n_kicks) kick_in_window(window);
    expect_no_fault_flags();
    if (crif.rst_req_count != r0) `uvm_error("SEQ", "reset occurred during correct servicing")
    wdt_disable();
  endtask
endclass

// ---------------- TP-EARLY : refresh inside closed window ------------------
class fswwdt_early_kick_seq extends fswwdt_timed_seq;
  `uvm_object_utils(fswwdt_early_kick_seq)
  constraint c_early { win_en == 1; window inside {[timeout/2 : timeout - 64]}; }
  function new(string name = "fswwdt_early_kick_seq"); super.new(name); endfunction
  task body();
    configure(timeout, window);
    enable(win_en, rst_en);
    kick();                                        // counter << window -> EARLY
    if (rst_en) expect_wdt_reset(200 * crif.wdt_period());
    else begin wait_flag(FLG_EARLY); clear_flags(); wdt_disable(); end
  endtask
endclass

// ---------------- TP-LATE : refresh after expiry -------------------------------
class fswwdt_late_kick_seq extends fswwdt_timed_seq;
  `uvm_object_utils(fswwdt_late_kick_seq)
  constraint c_late { rst_en == 0; }
  function new(string name = "fswwdt_late_kick_seq"); super.new(name); endfunction
  task body();
    configure(timeout, window);
    enable(win_en, rst_en);
    crif.wait_wdt(timeout + 20);                   // miss the deadline
    kick();                                        // too late: TMO already raised
    wait_flag(FLG_TMO);
    clear_flags();
    wdt_disable();
  endtask
endclass

// ---------------- TP-KEY : wrong refresh key -----------------------------------
class fswwdt_bad_key_seq extends fswwdt_timed_seq;
  `uvm_object_utils(fswwdt_bad_key_seq)
  rand bit [31:0] bad_key;
  constraint c_key { bad_key != KICK_KEY; }
  function new(string name = "fswwdt_bad_key_seq"); super.new(name); endfunction
  task body();
    kick(bad_key);                                 // while disabled: flag only
    wait_flag(FLG_KEYERR); clear_flags();
    configure(timeout, window);
    enable(win_en, rst_en);
    crif.wait_wdt(window + 8);
    kick(bad_key);
    if (rst_en) expect_wdt_reset(200 * crif.wdt_period());
    else begin wait_flag(FLG_KEYERR); clear_flags(); wdt_disable(); end
  endtask
endclass

// ---------------- TP-IRQ : early-warning interrupt service loop -----------
class fswwdt_ewi_irq_seq extends fswwdt_timed_seq;
  `uvm_object_utils(fswwdt_ewi_irq_seq)
  rand int unsigned n_irqs;
  constraint c_n   { n_irqs inside {[2:5]}; }
  constraint c_ewi { ewi inside {[window + 16 : timeout - 64]}; rst_en == 1; }
  function new(string name = "fswwdt_ewi_irq_seq"); super.new(name); endfunction
  task body();
    bit [31:0] s;
    configure(timeout, window, ewi, (1 << FLG_EWI));
    enable(win_en, rst_en);
    repeat (n_irqs) begin
      bit got = 0;
      fork begin : iso
        fork
          begin wait (crif.wdt_irq === 1'b1); got = 1; end
          #((timeout + 50) * crif.wdt_period());
        join_any
        disable fork;
      end join
      if (!got) begin `uvm_error("SEQ", "EWI interrupt not raised"); return; end
      rd(ADDR_STATUS, s);                            // "ISR"
      if (!s[FLG_EWI]) `uvm_error("SEQ", "IRQ without EWI flag")
      kick();
      clear_flags(1 << FLG_EWI);
      crif.wait_pclk(4);
      if (crif.wdt_irq !== 1'b0) `uvm_error("SEQ", "IRQ not deasserted after W1C")
    end
    wdt_disable();
  endtask
endclass

// ---------------- TP-LOCK : configuration lock -----------------------------
class fswwdt_lock_seq extends fswwdt_timed_seq;
  `uvm_object_utils(fswwdt_lock_seq)
  function new(string name = "fswwdt_lock_seq"); super.new(name); endfunction
  task body();
    bit [31:0] d;
    configure(timeout, window);
    enable(win_en, 1'b1, 1'b0, 1'b1);              // RST_EN + LOCK
    wr(ADDR_CTRL, 32'h0);          expect_err(1, "disable while locked");
    wr(ADDR_TIMEOUT, 32'h10);      expect_err(1, "TIMEOUT while locked");
    wr(ADDR_FAULT_INJ, 32'h1);     expect_err(1, "FAULT_INJ while locked");
    wr(ADDR_IRQ_EN, 32'h3F);       expect_err(0, "IRQ_EN stays writable");
    rd(ADDR_CTRL, d);
    kick_in_window(window);                        // servicing still works
    // stop servicing: locked watchdog must reset the system, reset clears LOCK
    expect_wdt_reset((timeout + 100) * crif.wdt_period());
    rd(ADDR_CTRL, d);
    if (d[CTRL_LOCK]) `uvm_error("SEQ", "LOCK survived reset")
  endtask
endclass

// ---------------- TP-FI : redundant counter fault injection ----------------
class fswwdt_fault_inj_seq extends fswwdt_timed_seq;
  `uvm_object_utils(fswwdt_fault_inj_seq)
  function new(string name = "fswwdt_fault_inj_seq"); super.new(name); endfunction
  task body();
    configure(timeout, window);
    enable(win_en, rst_en);
    crif.wait_wdt(20);
    wr(ADDR_FAULT_INJ, 32'h1);
    if (rst_en) expect_wdt_reset(200 * crif.wdt_period());
    else begin
      wait_flag(FLG_CNTERR);
      wait_cfg_idle();
      wr(ADDR_FAULT_INJ, 32'h0);
      clear_flags();
      wdt_disable();
    end
  endtask
endclass

// ---------------- TP-DBG : debug freeze -----------------------------------
class fswwdt_dbg_freeze_seq extends fswwdt_timed_seq;
  `uvm_object_utils(fswwdt_dbg_freeze_seq)
  constraint c_rst { rst_en == 0; }
  function new(string name = "fswwdt_dbg_freeze_seq"); super.new(name); endfunction
  task body();
    // with DBG_FRZ: a long halt must not cause a timeout
    configure(timeout, window);
    enable(win_en, rst_en, 1'b1);
    crif.wait_wdt(window / 2);
    crif.dbg_halt = 1'b1;
    crif.wait_wdt(3 * timeout);
    crif.dbg_halt = 1'b0;
    kick_in_window(window);
    expect_no_fault_flags();
    // without DBG_FRZ: same halt times out
    wdt_disable();
    configure(timeout, window);
    enable(win_en, rst_en, 1'b0);
    crif.dbg_halt = 1'b1;
    wait_flag(FLG_TMO);
    crif.dbg_halt = 1'b0;
    clear_flags();
    wdt_disable();
  endtask
endclass

// ---------------- TP-RAND : constrained random mix ----------------------------
class fswwdt_rand_seq extends fswwdt_base_seq;
  `uvm_object_utils(fswwdt_rand_seq)
  typedef enum {OP_CFG, OP_KICK_WIN, OP_KICK_NOW, OP_KICK_BAD, OP_RD, OP_WR_ANY,
                OP_CLEAR, OP_IDLE, OP_FI, OP_DISABLE} op_e;
  rand int unsigned n_ops;
  constraint c_n { n_ops inside {[40:120]}; }
  bit [CNT_W-1:0] cur_window;
  bit             known_running;     // we configured it and no reset since
  int unsigned    rst_seen;
  function new(string name = "fswwdt_rand_seq"); super.new(name); endfunction

  task body();
    op_e op;
    bit [31:0] d;
    repeat (n_ops) begin
      void'(std::randomize(op) with {
        op dist {OP_CFG := 10, OP_KICK_WIN := 30, OP_KICK_NOW := 8, OP_KICK_BAD := 3,
                 OP_RD := 15, OP_WR_ANY := 6, OP_CLEAR := 8, OP_IDLE := 10, OP_FI := 2,
                 OP_DISABLE := 4};
      });
      case (op)
        OP_CFG: begin
          fswwdt_timed_seq p = fswwdt_timed_seq::type_id::create("p");
          if (!p.randomize()) `uvm_error("SEQ", "randomize failed")
          if ($urandom_range(0, 1)) p.ewi = $urandom_range(1, p.timeout - 1);
          configure(p.timeout, p.window, p.ewi, $urandom());
          enable(p.win_en, p.rst_en, $urandom_range(0, 1));
          cur_window    = p.window;
          known_running = 1;
          rst_seen      = crif.reset_count;
        end
        OP_KICK_WIN: begin
          if (known_running && (crif.reset_count == rst_seen))
            kick_in_window(cur_window, 4, 2000, 0);
          else
            kick();
        end
        OP_KICK_NOW: kick();
        OP_KICK_BAD: kick($urandom() | 32'h1);       // never equals the key (key is even)
        OP_RD:       rd(12'(4 * $urandom_range(0, 10)), d);
        OP_WR_ANY: begin                              // never sets LOCK in random mode
          bit [ADDR_W-1:0] a = 12'($urandom_range(0, 11) * 4);
          d = $urandom();
          if (a == ADDR_CTRL) begin d[CTRL_LOCK] = 1'b0; known_running = 0; end
          wr(a, d);
        end
        OP_CLEAR:    clear_flags($urandom());
        OP_IDLE:     crif.wait_wdt($urandom_range(1, 300));
        OP_FI: begin wr(ADDR_FAULT_INJ, 1); wait_cfg_idle(); wr(ADDR_FAULT_INJ, 0); end
        OP_DISABLE:  begin wdt_disable(); known_running = 0; end
      endcase
    end
  endtask
endclass
