package fswwdt_seq_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import fswwdt_pkg::*;
  import apb_agent_pkg::*;

  `include "fswwdt_base_seq.sv"
  `include "fswwdt_seq_lib.sv"
  `include "fswwdt_seq_clkrst.sv"
endpackage : fswwdt_seq_pkg
