//-----------------------------------------------------------------------------
// fswwdt_seq_clkrst.sv : clock / reset / configuration-corner sequences
//   TP-CLK-*  : clock loss, clock ratio, frequency change
//   TP-RST-*  : async / sync / warm reset during operation, BITE and HALT
//   TP-CFG-*  : extreme TIMEOUT / WINDOW combinations
//-----------------------------------------------------------------------------

// Guarded wait on a TB-visible level. Returns 1 if reached before 'limit'.
// Kept as a class-scope helper so all clock/reset sequences share it.
class fswwdt_clkrst_base_seq extends fswwdt_timed_seq;
  `uvm_object_utils(fswwdt_clkrst_base_seq)
  int unsigned rst_len      = 16;
  int unsigned clkmon_limit = 64;

  function new(string name = "fswwdt_clkrst_base_seq"); super.new(name); endfunction

  task pre_start();
    super.pre_start();
    void'(uvm_config_db#(int unsigned)::get(m_sequencer, "", "rst_len",      rst_len));
    void'(uvm_config_db#(int unsigned)::get(m_sequencer, "", "clkmon_limit", clkmon_limit));
  endtask

  task automatic wait_rst_req(bit lvl, realtime limit, output bit ok);
    ok = 0;
    fork begin : iso
      fork
        begin wait (crif.wdt_rst_req === lvl); ok = 1; end
        #(limit);
      join_any
      disable fork;
    end join
  endtask

  task check_post_reset_state(string ctx);
    bit [31:0] s, c;
    rd(ADDR_CTRL, c);                           // predictor checks reset value
    rd(ADDR_STATUS, s);
    if (s[STS_STATE_LSB +: 3] != 3'(ST_DISABLED))
      `uvm_error("SEQ", $sformatf("%s: core state %0d after reset (exp DISABLED)",
                                  ctx, s[STS_STATE_LSB +: 3]))
    if (crif.wdt_rst_req !== 1'b0)
      `uvm_error("SEQ", $sformatf("%s: wdt_rst_req not cleared by reset", ctx))
  endtask
endclass

// ---------------- TP-CLK-01/02 : watchdog clock loss --------------------------
class fswwdt_clk_fail_seq extends fswwdt_clkrst_base_seq;
  `uvm_object_utils(fswwdt_clk_fail_seq)
  constraint c_to { timeout inside {[2000:4000]}; }   // overrides parent c_to
  function new(string name = "fswwdt_clk_fail_seq"); super.new(name); endfunction

  task body();
    int unsigned r0;
    realtime     det_limit;
    configure(timeout, window);
    enable(win_en, rst_en);
    crif.wait_wdt(10);
    r0        = crif.rst_req_count;
    det_limit = (clkmon_limit + 50) * crif.pclk_period() + 20 * crif.wdt_period();
    `uvm_info("SEQ", $sformatf("stopping wdt_clk (rst_en=%0b)", rst_en), UVM_LOW)
    crif.wdt_run = 1'b0;
    if (rst_en) begin
      expect_wdt_reset(det_limit);             // clock monitor must reset the SoC
      crif.wdt_run = 1'b1;                     // clock comes back after reset
      crif.wait_wdt(10);
      check_post_reset_state("after clk-fail reset");
    end else begin
      wait_flag(FLG_CLKFAIL, 5000);            // flag only, no reset
      if (crif.rst_req_count != r0) `uvm_error("SEQ", "reset requested with RST_EN=0")
      crif.wdt_run = 1'b1;                     // needed before CFG_PEND can clear
      crif.wait_wdt(10);
      clear_flags(1 << FLG_CLKFAIL);
      wdt_disable();
    end
  endtask
endclass

// ---------------- TP-CLK-03 : bus clock loss -> core must reset the SoC -------
class fswwdt_pclk_stop_seq extends fswwdt_clkrst_base_seq;
  `uvm_object_utils(fswwdt_pclk_stop_seq)
  constraint c_rst { rst_en == 1; }
  function new(string name = "fswwdt_pclk_stop_seq"); super.new(name); endfunction

  task body();
    configure(timeout, window);
    enable(win_en, rst_en);
    `uvm_info("SEQ", "stopping pclk: software can no longer service the watchdog", UVM_LOW)
    crif.pclk_run = 1'b0;
    expect_wdt_reset((timeout + 100) * crif.wdt_period());
    crif.pclk_run = 1'b1;
    crif.wait_pclk(10);
    check_post_reset_state("after pclk-loss reset");
  endtask
endclass

// ---------------- TP-CLK-05 : frequency change while running --------------------
class fswwdt_clk_freq_change_seq extends fswwdt_clkrst_base_seq;
  `uvm_object_utils(fswwdt_clk_freq_change_seq)
  constraint c_rst { rst_en == 1; win_en == 1; }
  function new(string name = "fswwdt_clk_freq_change_seq"); super.new(name); endfunction

  task body();
    realtime     plist[$] = '{60.0, 100.0, 40.0, 200.0, 40.0};  // all ratios in 4..32
    int unsigned r0;
    configure(timeout, window);
    enable(win_en, rst_en);
    r0 = crif.rst_req_count;
    foreach (plist[i]) begin
      kick_in_window(window);
      `uvm_info("SEQ", $sformatf("wdt_clk period -> %0.1f ns (running)", plist[i]), UVM_LOW)
      crif.set_wdt_period(plist[i]);           // glitch-free: applied on next half period
      kick_in_window(window);
    end
    expect_no_fault_flags();
    if (crif.rst_req_count != r0) `uvm_error("SEQ", "reset during frequency change")
    wdt_disable();
  endtask
endclass

// ---------------- TP-RST-03/04/05 : reset while counting ----------------------
class fswwdt_reset_mid_seq extends fswwdt_clkrst_base_seq;
  `uvm_object_utils(fswwdt_reset_mid_seq)
  rand bit          sync_rst;                  // 1 = pclk-aligned, 0 = arbitrary time
  rand int unsigned delay_cyc;
  rand int unsigned skew_ps;
  rand int unsigned rst_cycles;
  constraint c_dly  { delay_cyc  inside {[1 : timeout - 8]}; }
  constraint c_skew { skew_ps    inside {[0 : 9999]}; }
  constraint c_len  { rst_cycles inside {[1 : 20]}; }
  function new(string name = "fswwdt_reset_mid_seq"); super.new(name); endfunction

  task body();
    configure(timeout, window, 0, '1);
    enable(win_en, rst_en, 1'b0, $urandom_range(0, 1));   // sometimes locked
    if (!rst_en) kick(32'h1234_5678);                     // leave KEYERR + a fault event
    crif.wait_wdt(delay_cyc);
    `uvm_info("SEQ", $sformatf("%s reset after %0d wdt cycles", sync_rst ? "sync" : "async",
                               delay_cyc), UVM_LOW)
    if (sync_rst) crif.apply_sync_reset(rst_cycles);
    else begin #(skew_ps * 1ps); crif.apply_reset(rst_cycles); end
    crif.wait_pclk(8);
    check_post_reset_state("after mid-run reset");
    expect_no_fault_flags();                              // flags cleared by reset
  endtask
endclass

// ---------------- TP-RST-06/07 : reset at timeout, in BITE, in HALT ------------
class fswwdt_reset_bite_seq extends fswwdt_clkrst_base_seq;
  `uvm_object_utils(fswwdt_reset_bite_seq)
  typedef enum {AT_TIMEOUT, IN_BITE, IN_HALT} where_e;
  rand where_e where;
  constraint c_rst { rst_en == 1; }
  function new(string name = "fswwdt_reset_bite_seq"); super.new(name); endfunction

  task body();
    bit        ok;
    bit [31:0] s;
    crif.auto_reset_en = 1'b0;                 // TB owns the reset for this test
    configure(timeout, window);
    enable(win_en, rst_en);
    case (where)
      AT_TIMEOUT: crif.wait_wdt(timeout - 2 + $urandom_range(0, 4)); // straddle detection
      IN_BITE: begin
        wait_rst_req(1'b1, (timeout + 100) * crif.wdt_period(), ok);
        if (!ok) `uvm_error("SEQ", "BITE never entered")
        crif.wait_wdt($urandom_range(1, rst_len - 2));
      end
      IN_HALT: begin
        wait_rst_req(1'b1, (timeout + 100) * crif.wdt_period(), ok);
        if (!ok) `uvm_error("SEQ", "BITE never entered")
        wait_rst_req(1'b0, (rst_len + 10) * crif.wdt_period(), ok);
        if (!ok) `uvm_error("SEQ", "reset request longer than RST_LEN")
        crif.wait_wdt(20);
        rd(ADDR_STATUS, s);
        if (s[STS_STATE_LSB +: 3] != 3'(ST_HALT)) `uvm_error("SEQ", "not in HALT after BITE")
        kick();                                // HALT ignores everything
        crif.wait_wdt(20);
      end
    endcase
    `uvm_info("SEQ", $sformatf("reset applied %s", where.name()), UVM_LOW)
    crif.apply_reset($urandom_range(2, 20));
    crif.auto_reset_en = 1'b1;
    crif.wait_pclk(8);
    check_post_reset_state({"after reset ", where.name()});
  endtask
endclass

// ---------------- TP-CFG : extreme TIMEOUT / WINDOW combinations ----------------
// Large TIMEOUT values are exercised without waiting them out: an immediate
// kick checks EARLY detection (window>0) or a clean refresh (window==0).
class fswwdt_cfg_corner_seq extends fswwdt_base_seq;
  `uvm_object_utils(fswwdt_cfg_corner_seq)
  function new(string name = "fswwdt_cfg_corner_seq"); super.new(name); endfunction

  task one(bit [CNT_W-1:0] to, bit [CNT_W-1:0] win, bit we, bit [CNT_W-1:0] ew);
    `uvm_info("SEQ", $sformatf("corner: to=0x%08h win=0x%08h win_en=%0b ewi=%0d", to, win, we, ew),
              UVM_MEDIUM)
    configure(to, win, ew);
    enable(we, 1'b0);
    if (to <= 3)            wait_flag(FLG_TMO);        // expires continuously
    else if (we && win > 0) begin kick(); wait_flag(FLG_EARLY); end
    else begin kick(); crif.wait_wdt(10); expect_no_fault_flags(); end
    wdt_disable();
    clear_flags();
  endtask

  task body();
    one(1, 0, 0, 0);            one(2, 1, 1, 0);            one(3, 0, 1, 0);
    one(3, 1, 1, 2);
    one(200, 0, 1, 0);          one(200, 40, 1, 100);       one(200, 100, 1, 0);
    one(200, 180, 1, 190);
    one(1000, 0, 0, 500);       one(1000, 200, 1, 0);       one(1000, 500, 1, 700);
    one(1000, 900, 1, 0);
    one(100000, 0, 0, 0);       one(100000, 20000, 1, 0);   one(100000, 50000, 1, 90000);
    one(100000, 90000, 1, 0);
    one('1, 0, 0, 0);           one('1, 32'h4000_0000, 1, 0);
    one('1, 32'h8000_0000, 1, 32'hF000_0000);           one('1, 32'hE000_0000, 1, 0);
  endtask
endclass
