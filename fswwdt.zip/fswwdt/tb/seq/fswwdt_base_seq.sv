//-----------------------------------------------------------------------------
// fswwdt_base_seq : "driver API" layer used by every stimulus sequence.
// Mirrors how production firmware would program the watchdog.
//-----------------------------------------------------------------------------
class fswwdt_base_seq extends uvm_sequence #(apb_seq_item);
  `uvm_object_utils(fswwdt_base_seq)

  virtual clk_rst_if crif;
  bit                last_err;
  bit                saw_abort;

  function new(string name = "fswwdt_base_seq");
    super.new(name);
  endfunction

  task pre_start();
    if (!uvm_config_db#(virtual clk_rst_if)::get(m_sequencer, "", "crif", crif))
      `uvm_fatal("NOVIF", "crif not visible to sequence")
  endtask

  // ---------------- primitive accesses ------------------------------------
  task wr(bit [ADDR_W-1:0] a, bit [31:0] d);
    apb_seq_item it = apb_seq_item::type_id::create("it");
    start_item(it);
    it.addr = a; it.write = 1'b1; it.wdata = d;
    finish_item(it);
    last_err = it.slverr;
    if (it.aborted) saw_abort = 1'b1;
  endtask

  task rd(bit [ADDR_W-1:0] a, output bit [31:0] d);
    apb_seq_item it = apb_seq_item::type_id::create("it");
    start_item(it);
    it.addr = a; it.write = 1'b0; it.wdata = '0;
    finish_item(it);
    d        = it.rdata;
    last_err = it.slverr;
    if (it.aborted) saw_abort = 1'b1;
  endtask

  task expect_err(bit exp, string what);
    if (last_err !== exp)
      `uvm_error("SEQ", $sformatf("%s: PSLVERR=%0b expected %0b", what, last_err, exp))
  endtask

  // ---------------- polling helpers --------------------------------------
  task wait_status_clear(int unsigned bitpos, int unsigned max_polls = 2000);
    bit [31:0] s;
    repeat (max_polls) begin
      rd(ADDR_STATUS, s);
      if (!s[bitpos]) return;
    end
    `uvm_error("SEQ", $sformatf("STATUS[%0d] never cleared", bitpos))
  endtask

  task wait_cfg_idle();  wait_status_clear(STS_CFG_PEND);  endtask
  task wait_kick_idle(); wait_status_clear(STS_KICK_PEND); endtask

  task wait_flag(int unsigned flg, int unsigned max_polls = 20000, bit fatal_if_missing = 1);
    bit [31:0] s;
    repeat (max_polls) begin
      rd(ADDR_STATUS, s);
      if (s[flg]) return;
    end
    if (fatal_if_missing) `uvm_error("SEQ", $sformatf("flag %0d never set", flg))
  endtask

  task clear_flags(bit [NUM_FLAGS-1:0] m = '1); wr(ADDR_STATUS, 32'(m)); endtask

  // ---------------- watchdog programming ------------------------------------
  task wdt_disable();
    bit [31:0] c;
    wait_cfg_idle();
    rd(ADDR_CTRL, c);
    c[CTRL_EN]   = 1'b0;
    c[CTRL_LOCK] = 1'b0;
    wr(ADDR_CTRL, c);
    wait_cfg_idle();
  endtask

  task configure(bit [CNT_W-1:0] timeout, bit [CNT_W-1:0] window = 0,
                 bit [CNT_W-1:0] ewi = 0, bit [NUM_FLAGS-1:0] irq_en = '1);
    wdt_disable();
    wr(ADDR_TIMEOUT, timeout); wait_cfg_idle();
    wr(ADDR_WINDOW,  window);  wait_cfg_idle();
    wr(ADDR_EWI,     ewi);     wait_cfg_idle();
    wr(ADDR_IRQ_EN,  32'(irq_en));
    clear_flags();
  endtask

  task enable(bit win_en, bit rst_en, bit dbg_frz = 0, bit lock = 0);
    bit [31:0] c = '0;
    c[CTRL_EN] = 1'b1; c[CTRL_WIN_EN] = win_en; c[CTRL_RST_EN] = rst_en;
    c[CTRL_DBG_FRZ] = dbg_frz; c[CTRL_LOCK] = lock;
    wait_cfg_idle();
    wr(ADDR_CTRL, c);
    wait_cfg_idle();
  endtask

  task kick(bit [31:0] key = KICK_KEY);
    wait_kick_idle();
    wr(ADDR_KICK, key);
  endtask

  // Firmware-style refresh: wait until COUNT shows the window is open.
  task kick_in_window(bit [CNT_W-1:0] window, int unsigned margin = 4,
                      int unsigned max_polls = 20000, bit err_if_missing = 1);
    bit [31:0] c;
    wait_kick_idle();
    crif.wait_wdt(8);                 // let the COUNT snapshot refresh
    repeat (max_polls) begin
      rd(ADDR_COUNT, c);
      if (c >= window + margin) begin kick(); return; end
    end
    if (err_if_missing) `uvm_error("SEQ", "window never opened")
  endtask

  // Wait for the reset-controller model to see a watchdog reset request.
  task expect_wdt_reset(realtime limit);
    int unsigned c0 = crif.rst_req_count;
    int unsigned r0 = crif.reset_count;
    bit          got = 0;
    fork begin : iso
      fork
        begin wait (crif.rst_req_count != c0); got = 1; end
        #(limit);
      join_any
      disable fork;
    end join
    if (!got) `uvm_error("SEQ", "expected watchdog reset request did not occur")
    else      `uvm_info("SEQ", "watchdog reset request observed", UVM_MEDIUM)
    if (got && crif.auto_reset_en) begin
      wait (crif.reset_count != r0);           // reset-controller model reacted
      wait (crif.presetn === 1'b1);            // and released reset
    end
  endtask

  task expect_no_fault_flags();
    bit [31:0] s;
    rd(ADDR_STATUS, s);
    if (s[FLG_TMO] || s[FLG_EARLY] || s[FLG_KEYERR] || s[FLG_CNTERR])
      `uvm_error("SEQ", $sformatf("unexpected fault flag(s): STATUS=0x%08h", s))
  endtask
endclass : fswwdt_base_seq
