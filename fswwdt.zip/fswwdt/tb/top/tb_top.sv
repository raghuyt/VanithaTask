//-----------------------------------------------------------------------------
// tb_top.sv : static top. Instantiates interfaces + DUT, wires white-box
// probes, models the SoC reset controller and launches UVM.
//-----------------------------------------------------------------------------
`timescale 1ns/1ps
module tb_top;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import fswwdt_pkg::*;
  import fswwdt_test_pkg::*;

  localparam int unsigned RST_LEN      = 16;
  localparam int unsigned CLKMON_LIMIT = 64;

  // ---------------- interfaces ---------------------------------------------
  clk_rst_if   crif ();
  apb_if       apb  (.pclk(crif.pclk), .presetn(crif.presetn));
  wdt_probe_if prb  (.wdt_clk(crif.wdt_clk));

  wire irq_w, rst_req_w;

  // ---------------- DUT ----------------------------------------------------------
  fswwdt_top #(
    .RST_LEN      (RST_LEN),
    .CLKMON_LIMIT (CLKMON_LIMIT)
  ) u_dut (
    .pclk          (crif.pclk),
    .presetn       (crif.presetn),
    .psel          (apb.psel),
    .penable       (apb.penable),
    .pwrite        (apb.pwrite),
    .paddr         (apb.paddr),
    .pwdata        (apb.pwdata),
    .prdata        (apb.prdata),
    .pready        (apb.pready),
    .pslverr       (apb.pslverr),
    .wdt_clk       (crif.wdt_clk),
    .scan_mode_i   (crif.scan_mode),
    .dbg_halt_i    (crif.dbg_halt),
    .wdt_irq_o     (irq_w),
    .wdt_rst_req_o (rst_req_w)
  );

  assign crif.wdt_irq     = irq_w;
  assign crif.wdt_rst_req = rst_req_w;

  // ---------------- white-box probes (read-only) ------------------------------
  // Probing internal nets is a deliberate trade-off: it lets the scoreboard
  // run a cycle-accurate model of the core instead of inferring its state
  // through a lagging CDC snapshot. Probe paths are kept in this one place.
  assign apb.cfg_pend  = u_dut.u_regs.cfg_pend;
  assign apb.kick_pend = u_dut.kick_busy;

  assign prb.wrst_n    = u_dut.wrst_n;
  assign prb.cfg       = u_dut.cfg_w;
  assign prb.kick_good = u_dut.kick_good_core;
  assign prb.kick_bad  = u_dut.kick_bad_core;
  assign prb.dbg_halt  = u_dut.dbg_halt_w;
  assign prb.state     = u_dut.u_core.state_q;
  assign prb.cnt       = u_dut.u_core.cnt_q;
  assign prb.cnt_n     = u_dut.u_core.cnt_n_q;
  assign prb.evt       = u_dut.u_core.evt_o;
  assign prb.rst_req   = u_dut.u_core.rst_req_o;

  // ---------------- SoC reset-controller model -----------------------------------
  // wdt_rst_req is asynchronous to both clocks; a real reset controller
  // synchronizes it and pulses the system reset. Here: fixed reaction delay,
  // then a wall-clock timed reset (works with a stopped clock).
  always @(posedge rst_req_w) begin
    crif.rst_req_count++;
    `uvm_info("RSTC", $sformatf("wdt_rst_req asserted (#%0d)%s", crif.rst_req_count,
                                crif.auto_reset_en ? "" : " - auto reset disabled"), UVM_LOW)
    if (crif.auto_reset_en)
      fork
        begin
          #(crif.rstc_delay);
          crif.apply_reset(crif.rstc_pulse_cycles);
        end
      join_none
  end

  // ---------------- UVM launch ----------------------------------------------------------
  initial begin
    uvm_config_db#(virtual clk_rst_if)::set  (null, "*", "crif",         crif);
    uvm_config_db#(virtual apb_if)::set      (null, "*", "apb_vif",      apb);
    uvm_config_db#(virtual wdt_probe_if)::set(null, "*", "prb_vif",      prb);
    uvm_config_db#(int unsigned)::set        (null, "*", "rst_len",      RST_LEN);
    uvm_config_db#(int unsigned)::set        (null, "*", "clkmon_limit", CLKMON_LIMIT);
    run_test();
  end

  // Optional SHM dump from source (+define+FSWWDT_WAVES). The Tcl route
  // (sim/scripts/waves.tcl) is preferred: no recompile to change probes.
`ifdef FSWWDT_WAVES
  initial begin
    $shm_open("waves.shm");
    $shm_probe(tb_top, "AS");      // verify probe-scope letters in your Xcelium docs
  end
`endif
endmodule : tb_top
