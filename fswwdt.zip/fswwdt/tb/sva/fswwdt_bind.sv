//-----------------------------------------------------------------------------
// fswwdt_bind.sv : attaches assertion modules without touching the RTL.
// Compiled only in simulation/formal file lists, never in synthesis.
// NOTE: hierarchical (downward) references in bind port connections resolve
// relative to the bind target scope - supported by Xcelium/Jasper; confirm
// with your tool version if elaboration complains.
//-----------------------------------------------------------------------------
bind fswwdt_core fswwdt_core_sva #(.RST_LEN(RST_LEN)) u_core_sva (.*);

bind fswwdt_top fswwdt_top_sva u_top_sva (
  .pclk          (pclk),
  .prst_n        (prst_n),
  .psel          (psel),
  .penable       (penable),
  .pwrite        (pwrite),
  .paddr         (paddr),
  .pwdata        (pwdata),
  .prdata        (prdata),
  .pready        (pready),
  .pslverr       (pslverr),
  .wdt_irq_o     (wdt_irq_o),
  .wdt_rst_req_o (wdt_rst_req_o),
  .flags_q       (u_regs.flags_q),
  .irq_en_q      (u_regs.irq_en_q),
  .lock_q        (u_regs.lock_q),
  .en_q          (u_regs.en_q),
  .win_en_q      (u_regs.win_en_q),
  .timeout_q     (u_regs.timeout_q),
  .window_q      (u_regs.window_q),
  .ewi_q         (u_regs.ewi_q),
  .cfg_pend      (u_regs.cfg_pend),
  .kick_busy     (kick_busy),
  .rst_en_p      (rst_en_p),
  .clkfail_p     (clkfail_p),
  .clkfail_rst_p (clkfail_rst_p)
);
