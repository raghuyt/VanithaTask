//-----------------------------------------------------------------------------
// fswwdt_core_sva.sv : assertions on the watchdog core (wdt_clk domain).
// Bound into every fswwdt_core instance (see fswwdt_bind.sv); ports use the
// core's internal names so the bind can use .* implicit connections.
//
// Proof strategy for "timeout after exactly TIMEOUT cycles" (by induction):
//   a_cnt_start    : every (re)start loads 0
//   a_cnt_inc      : every tick without fault/kick/disable adds exactly 1
//   a_cnt_hold     : no tick -> counter holds (debug freeze)
//   a_cnt_bound    : counter never reaches TIMEOUT while running
//   a_tmo_at_limit : the timeout fault fires iff the next count == TIMEOUT
//-----------------------------------------------------------------------------
module fswwdt_core_sva
  import fswwdt_pkg::*;
#(
  parameter int unsigned RST_LEN = 16
) (
  input logic               clk_i,
  input logic               rst_ni,
  input wdt_cfg_t           cfg_i,
  input logic               kick_good_i,
  input logic               kick_bad_i,
  input wdt_state_e         state_q,
  input logic [CNT_W-1:0]   cnt_q,
  input logic [CNT_W-1:0]   cnt_n_q,
  input logic               running,
  input logic               tick,
  input logic               fault,
  input logic               tmo_hit,
  input logic               ewi_hit,
  input logic               early_kick,
  input logic               key_flt,
  input logic               kick_ok,
  input logic               cnt_err,
  input logic               fi_rise,
  input logic [NUM_EVT-1:0] evt_o,
  input logic               rst_req_o
);

  default clocking cb @(posedge clk_i); endclocking
  default disable iff (!rst_ni);

  // ---------------- FSM integrity -------------------------------------------
  a_state_legal:   assert property (state_q inside {ST_DISABLED, ST_CLOSED, ST_OPEN,
                                                    ST_BITE, ST_HALT})
    else $error("core FSM in illegal state %0d", state_q);
  a_no_x:          assert property (!$isunknown({state_q, cnt_q, rst_req_o, evt_o}));
  a_halt_sticky:   assert property (state_q == ST_HALT |=> state_q == ST_HALT);
  a_bite_to_halt:  assert property ($fell(state_q == ST_BITE) |-> state_q == ST_HALT);
  a_dis_no_count:  assert property (state_q == ST_DISABLED |-> cnt_q == '0);

  // ---------------- counter (timeout detection) ---------------------------------
  a_cnt_start:     assert property (state_q == ST_DISABLED && cfg_i.en
                                    |=> cnt_q == '0 && state_q inside {ST_CLOSED, ST_OPEN});
  a_cnt_inc:       assert property (tick && !fault && cfg_i.en && !kick_ok
                                    |=> cnt_q == $past(cnt_q) + 1'b1);
  a_cnt_hold:      assert property (running && !tick && !fault && cfg_i.en && !kick_ok
                                    |=> $stable(cnt_q));
  a_cnt_bound:     assert property (running && cfg_i.en |-> cnt_q < cfg_i.timeout);
  a_tmo_at_limit:  assert property (tmo_hit |-> tick && (cnt_q == cfg_i.timeout - 1'b1));
  a_tmo_not_miss:  assert property (tick && (cnt_q == cfg_i.timeout - 1'b1) |-> tmo_hit);
  a_tmo_event:     assert property (tmo_hit |=> evt_o[EVT_TMO]);

  // ---------------- window validation ----------------------------------------------
  a_closed_inv:    assert property (state_q == ST_CLOSED
                                    |-> cfg_i.win_en && (cnt_q < cfg_i.window));
  a_open_inv:      assert property (state_q == ST_OPEN
                                    |-> !cfg_i.win_en || (cnt_q >= cfg_i.window));
  a_early_fault:   assert property (kick_good_i && state_q == ST_CLOSED |-> fault);
  a_early_event:   assert property (early_kick |=> evt_o[EVT_EARLY]);
  a_kick_reload:   assert property (kick_ok && !fault && cfg_i.en
                                    |=> cnt_q == '0 && state_q inside {ST_CLOSED, ST_OPEN});

  // ---------------- early warning (interrupt source) ----------------------------
  a_ewi_at_value:  assert property (ewi_hit |-> cfg_i.ewi != '0 && cnt_q == cfg_i.ewi - 1'b1);
  a_ewi_event:     assert property (ewi_hit |=> evt_o[EVT_EWI]);
  a_evt_pulse:     assert property (evt_o[EVT_TMO] |=> !evt_o[EVT_TMO] || $past(tmo_hit));

  // ---------------- error handling ------------------------------------------------
  a_key_fault:     assert property (kick_bad_i && running |-> fault);
  a_fi_detect:     assert property (fi_rise && running && !fault && cfg_i.en |=> cnt_err);
  a_cnterr_event:  assert property (cnt_err |=> evt_o[EVT_CNTERR]);
  a_fault_bite:    assert property (fault && cfg_i.rst_en |=> state_q == ST_BITE);
  a_fault_restart: assert property (fault && !cfg_i.rst_en
                                    |=> cnt_q == '0 && state_q inside {ST_CLOSED, ST_OPEN});
  a_fault_prio:    assert property (fault && !cfg_i.en && cfg_i.rst_en |=> state_q == ST_BITE);
  a_disable:       assert property (running && !fault && !cfg_i.en |=> state_q == ST_DISABLED);

  // ---------------- reset generation ----------------------------------------------
  a_rst_is_bite:   assert property (rst_req_o == (state_q == ST_BITE));
  a_rst_len:       assert property ($rose(rst_req_o) |-> rst_req_o [*RST_LEN] ##1 !rst_req_o);
  a_rst_cause:     assert property ($rose(rst_req_o) |-> $past(fault && cfg_i.rst_en) ||
                                    !($past(state_q) inside {ST_DISABLED, ST_CLOSED, ST_OPEN,
                                                             ST_BITE, ST_HALT}));
  a_no_rst_dis:    assert property (state_q == ST_DISABLED |-> !rst_req_o);

  // ---------------- coverage of interesting behaviour -------------------------------
  c_early_kick:    cover property (early_kick);
  c_kick_ok:       cover property (kick_ok ##1 state_q == ST_CLOSED);
  c_tmo_bite:      cover property (tmo_hit && cfg_i.rst_en ##1 state_q == ST_BITE);
  c_tmo_restart:   cover property (tmo_hit && !cfg_i.rst_en);
  c_bite_halt:     cover property (state_q == ST_BITE ##1 state_q == ST_HALT);
  c_freeze:        cover property (running && !tick [*10]);
  c_fi:            cover property (fi_rise && running ##1 cnt_err);
  c_ewi_then_kick: cover property (ewi_hit ##[1:$] kick_ok);
  c_kick_last:     cover property (kick_ok && (cnt_q == cfg_i.timeout - 1'b1));  // last legal cycle
  c_fault_and_kick:cover property (tmo_hit && kick_good_i);                       // priority corner
endmodule : fswwdt_core_sva
