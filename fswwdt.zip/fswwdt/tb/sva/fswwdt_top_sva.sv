//-----------------------------------------------------------------------------
// fswwdt_top_sva.sv : APB protocol, register-rule, interrupt and reset-output
// assertions (pclk domain). Bound to fswwdt_top with hierarchical port
// connections into u_regs / u_clk_mon (see fswwdt_bind.sv).
//-----------------------------------------------------------------------------
module fswwdt_top_sva
  import fswwdt_pkg::*;
(
  input logic                 pclk,
  input logic                 prst_n,
  input logic                 psel,
  input logic                 penable,
  input logic                 pwrite,
  input logic [ADDR_W-1:0]    paddr,
  input logic [DATA_W-1:0]    pwdata,
  input logic [DATA_W-1:0]    prdata,
  input logic                 pready,
  input logic                 pslverr,
  input logic                 wdt_irq_o,
  input logic                 wdt_rst_req_o,
  input logic [NUM_FLAGS-1:0] flags_q,
  input logic [NUM_FLAGS-1:0] irq_en_q,
  input logic                 lock_q,
  input logic                 en_q,
  input logic                 win_en_q,
  input logic [CNT_W-1:0]     timeout_q,
  input logic [CNT_W-1:0]     window_q,
  input logic [CNT_W-1:0]     ewi_q,
  input logic                 cfg_pend,
  input logic                 kick_busy,
  input logic                 rst_en_p,
  input logic                 clkfail_p,
  input logic                 clkfail_rst_p
);

  default clocking cb @(posedge pclk); endclocking
  default disable iff (!prst_n);

  logic acc, wr, rd;
  assign acc = psel & penable;
  assign wr  = acc &  pwrite;
  assign rd  = acc & ~pwrite;

  // ---------------- APB protocol (checks the bus master = TB driver / SoC) -----
  a_pready:        assert property (pready);                       // zero wait state
  a_setup_access:  assert property (psel && !penable |=> psel && penable);
  a_setup_stable:  assert property (psel && !penable
                                    |=> $stable(paddr) && $stable(pwrite) && $stable(pwdata));
  a_access_end:    assert property (acc |=> !penable);             // PREADY=1 -> 1 cycle
  a_penable_psel:  assert property (penable |-> psel);
  a_err_in_access: assert property (pslverr |-> acc);
  a_rdata_known:   assert property (rd |-> !$isunknown(prdata));
  a_ctrl_known:    assert property (!$isunknown({psel, penable}));

  // ---------------- register protocol rules (PSLVERR) ----------------------------
  a_err_unmapped:  assert property (acc && ((paddr[1:0] != 2'b00) || (paddr > ADDR_ID)) |-> pslverr);
  a_err_ro:        assert property (wr && (paddr inside {ADDR_COUNT, ADDR_ID}) |-> pslverr);
  a_err_locked:    assert property (wr && lock_q && (paddr inside {ADDR_CTRL, ADDR_TIMEOUT,
                                    ADDR_WINDOW, ADDR_EWI, ADDR_FAULT_INJ}) |-> pslverr);
  a_err_run_cfg:   assert property (wr && en_q && (paddr inside {ADDR_TIMEOUT, ADDR_WINDOW,
                                    ADDR_EWI}) |-> pslverr);
  a_err_illegal:   assert property (wr && (paddr == ADDR_CTRL) && pwdata[CTRL_EN] &&
                                    !cfg_legal(pwdata[CTRL_WIN_EN], timeout_q, window_q, ewi_q)
                                    |-> pslverr);
  a_err_kick_busy: assert property (wr && (paddr == ADDR_KICK) && kick_busy |-> pslverr);
  a_irq_en_ok:     assert property (acc && (paddr == ADDR_IRQ_EN) |-> !pslverr);
  a_err_no_update: assert property (wr && pslverr
                                    |=> $stable({timeout_q, window_q, ewi_q, en_q, win_en_q, lock_q}));
  a_lock_sticky:   assert property (lock_q |=> lock_q);
  a_locked_stable: assert property (lock_q |=> $stable({timeout_q, window_q, ewi_q, en_q, win_en_q}));
  a_run_timing:    assert property (en_q && $past(en_q) |-> $stable({timeout_q, window_q, ewi_q}));

  // ---------------- flags / interrupt ---------------------------------------------
  a_irq_follow:    assert property (1'b1 |=> wdt_irq_o == $past(|(flags_q & irq_en_q)));
  a_keyerr_flag:   assert property (wr && (paddr == ADDR_KICK) && !kick_busy && (pwdata != KICK_KEY)
                                    |=> flags_q[FLG_KEYERR]);
  for (genvar i = 0; i < NUM_FLAGS; i++) begin : g_flag
    // sticky: only a W1C write of this bit can clear it
    a_sticky: assert property (flags_q[i] && !(wr && !pslverr && (paddr == ADDR_STATUS) && pwdata[i])
                               |=> flags_q[i]);
    c_set:    cover  property ($rose(flags_q[i]));
  end

  // ---------------- reset output / clock-loss handling --------------------------------
  a_rst_known:     assert property (!$isunknown(wdt_rst_req_o));
  // fail flag and reset request are set on the same edge from RST_EN of the
  // previous cycle, hence $past()
  a_clkfail_rst:   assert property ($rose(clkfail_p) && $past(rst_en_p) |-> clkfail_rst_p);
  a_clkfail_out:   assert property (clkfail_rst_p |-> wdt_rst_req_o);
  a_clkfail_stick: assert property (clkfail_rst_p |=> clkfail_rst_p);

  c_lock:          cover property ($rose(lock_q));
  c_irq:           cover property ($rose(wdt_irq_o));
  c_err_locked:    cover property (wr && lock_q && pslverr);
  c_err_pend:      cover property (wr && cfg_pend && pslverr);
  c_err_kick:      cover property (wr && (paddr == ADDR_KICK) && kick_busy);
  c_clkfail_rst:   cover property ($rose(clkfail_rst_p));
endmodule : fswwdt_top_sva
