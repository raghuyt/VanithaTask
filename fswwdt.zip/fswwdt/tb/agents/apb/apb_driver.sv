class apb_driver extends uvm_driver #(apb_seq_item);
  `uvm_component_utils(apb_driver)

  virtual apb_if vif;
  int unsigned   post_reset_idle = 4;   // pclk cycles after presetn rise
  int unsigned   rst_cnt;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual apb_if)::get(this, "", "apb_vif", vif))
      `uvm_fatal("NOVIF", "apb_vif not set")
  endfunction

  task run_phase(uvm_phase phase);
    drive_idle();
    fork
      forever begin                                 // cycles since reset release
        @(posedge vif.pclk);
        if (vif.presetn !== 1'b1) rst_cnt = 0;
        else if (rst_cnt < 1000)  rst_cnt++;
      end
    join_none

    forever begin
      seq_item_port.get_next_item(req);
      while ((vif.presetn !== 1'b1) || (rst_cnt < post_reset_idle)) @(posedge vif.pclk);
      req.aborted = 1'b0;
      fork begin : isolate                       // isolate so 'disable fork'
        fork                                     // cannot kill rst_cnt thread
          drive_item(req);
          begin @(negedge vif.presetn); req.aborted = 1'b1; end
        join_any
        disable fork;
      end join
      if (req.aborted) drive_idle();
      `uvm_info("APB_DRV", req.convert2string(), UVM_HIGH)
      seq_item_port.item_done();
    end
  endtask

  task drive_item(apb_seq_item t);
    // SETUP phase
    @(vif.drv_cb);
    vif.drv_cb.psel    <= 1'b1;
    vif.drv_cb.penable <= 1'b0;
    vif.drv_cb.pwrite  <= t.write;
    vif.drv_cb.paddr   <= t.addr;
    vif.drv_cb.pwdata  <= t.write ? t.wdata : 32'h0;
    // ACCESS phase
    @(vif.drv_cb);
    vif.drv_cb.penable <= 1'b1;
    do @(vif.drv_cb); while (vif.drv_cb.pready !== 1'b1);
    t.rdata  = vif.drv_cb.prdata;
    t.slverr = vif.drv_cb.pslverr;
    vif.drv_cb.psel    <= 1'b0;
    vif.drv_cb.penable <= 1'b0;
  endtask

  function void drive_idle();
    vif.psel    = 1'b0;
    vif.penable = 1'b0;
  endfunction
endclass : apb_driver
