class apb_monitor extends uvm_monitor;
  `uvm_component_utils(apb_monitor)

  virtual apb_if                  vif;
  uvm_analysis_port #(apb_seq_item) ap;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual apb_if)::get(this, "", "apb_vif", vif))
      `uvm_fatal("NOVIF", "apb_vif not set")
  endfunction

  task run_phase(uvm_phase phase);
    apb_seq_item t;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.presetn !== 1'b1) continue;
      if (vif.mon_cb.psel && vif.mon_cb.penable && vif.mon_cb.pready) begin
        t           = apb_seq_item::type_id::create("t");
        t.addr      = vif.mon_cb.paddr;
        t.write     = vif.mon_cb.pwrite;
        t.wdata     = vif.mon_cb.pwdata;
        t.rdata     = vif.mon_cb.prdata;
        t.slverr    = vif.mon_cb.pslverr;
        t.cfg_pend  = vif.mon_cb.cfg_pend;
        t.kick_pend = vif.mon_cb.kick_pend;
        `uvm_info("APB_MON", t.convert2string(), UVM_HIGH)
        ap.write(t);
      end
    end
  endtask
endclass : apb_monitor
