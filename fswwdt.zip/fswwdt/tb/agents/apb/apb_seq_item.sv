class apb_seq_item extends uvm_sequence_item;
  rand bit [11:0] addr;
  rand bit        write;
  rand bit [31:0] wdata;
  // response / observed
  bit [31:0]      rdata;
  bit             slverr;
  bit             aborted;     // transfer killed by reset
  bit             cfg_pend;    // probe values at ACCESS phase (monitor only)
  bit             kick_pend;

  constraint c_align { soft addr[1:0] == 2'b00; }
  constraint c_map   { soft addr inside {[12'h000:12'h028]}; }

  `uvm_object_utils_begin(apb_seq_item)
    `uvm_field_int(addr,   UVM_ALL_ON | UVM_HEX)
    `uvm_field_int(write,  UVM_ALL_ON)
    `uvm_field_int(wdata,  UVM_ALL_ON | UVM_HEX)
    `uvm_field_int(rdata,  UVM_ALL_ON | UVM_HEX)
    `uvm_field_int(slverr, UVM_ALL_ON)
    `uvm_field_int(aborted,UVM_ALL_ON)
  `uvm_object_utils_end

  function new(string name = "apb_seq_item");
    super.new(name);
  endfunction

  function string convert2string();
    return $sformatf("%s addr=0x%03h wdata=0x%08h rdata=0x%08h slverr=%0b cfg_pend=%0b kick_pend=%0b%s",
                     write ? "WR" : "RD", addr, wdata, rdata, slverr, cfg_pend, kick_pend,
                     aborted ? " ABORTED" : "");
  endfunction
endclass : apb_seq_item
