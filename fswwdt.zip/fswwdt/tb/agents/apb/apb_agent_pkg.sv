package apb_agent_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  `include "apb_seq_item.sv"
  typedef uvm_sequencer #(apb_seq_item) apb_sequencer;
  `include "apb_driver.sv"
  `include "apb_monitor.sv"
  `include "apb_agent.sv"
endpackage : apb_agent_pkg
