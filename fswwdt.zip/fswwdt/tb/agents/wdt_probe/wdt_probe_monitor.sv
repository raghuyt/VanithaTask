class wdt_probe_monitor extends uvm_monitor;
  `uvm_component_utils(wdt_probe_monitor)

  virtual wdt_probe_if               vif;
  uvm_analysis_port #(wdt_core_txn)  ap;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual wdt_probe_if)::get(this, "", "prb_vif", vif))
      `uvm_fatal("NOVIF", "prb_vif not set")
  endfunction

  task run_phase(uvm_phase phase);
    wdt_core_txn t;
    forever begin
      @(vif.mon_cb);
      t           = wdt_core_txn::type_id::create("t");
      t.rst_n     = (vif.mon_cb.wrst_n === 1'b1);
      t.cfg       = vif.mon_cb.cfg;
      t.kick_good = vif.mon_cb.kick_good;
      t.kick_bad  = vif.mon_cb.kick_bad;
      t.dbg_halt  = vif.mon_cb.dbg_halt;
      t.state     = vif.mon_cb.state;
      t.cnt       = vif.mon_cb.cnt;
      t.cnt_n     = vif.mon_cb.cnt_n;
      t.evt       = vif.mon_cb.evt;
      t.rst_req   = vif.mon_cb.rst_req;
      ap.write(t);
    end
  endtask
endclass : wdt_probe_monitor
