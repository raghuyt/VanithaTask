class wdt_probe_agent extends uvm_agent;
  `uvm_component_utils(wdt_probe_agent)
  wdt_probe_monitor mon;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    mon = wdt_probe_monitor::type_id::create("mon", this);   // always passive
  endfunction
endclass : wdt_probe_agent
