package wdt_probe_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import fswwdt_pkg::*;

  `include "wdt_core_txn.sv"
  `include "wdt_probe_monitor.sv"
  `include "wdt_probe_agent.sv"
endpackage : wdt_probe_pkg
