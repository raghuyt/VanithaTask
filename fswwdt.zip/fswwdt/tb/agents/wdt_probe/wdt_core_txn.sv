// One sample of the watchdog core per wdt_clk edge (pre-edge values).
class wdt_core_txn extends uvm_sequence_item;
  `uvm_object_utils(wdt_core_txn)

  bit                 rst_n;
  wdt_cfg_t           cfg;
  bit                 kick_good, kick_bad, dbg_halt;
  wdt_state_e         state;
  bit [CNT_W-1:0]     cnt, cnt_n;
  bit [NUM_EVT-1:0]   evt;
  bit                 rst_req;

  function new(string name = "wdt_core_txn");
    super.new(name);
  endfunction

  function string convert2string();
    return $sformatf("rst_n=%0b st=%s cnt=%0d cnt_n=0x%08h evt=%04b rst_req=%0b kick(g/b)=%0b/%0b dbg=%0b | cfg en=%0b win=%0b rst=%0b frz=%0b fi=%0b to=%0d win=%0d ewi=%0d",
      rst_n, state.name(), cnt, cnt_n, evt, rst_req, kick_good, kick_bad, dbg_halt,
      cfg.en, cfg.win_en, cfg.rst_en, cfg.dbg_frz, cfg.fi, cfg.timeout, cfg.window, cfg.ewi);
  endfunction
endclass : wdt_core_txn
