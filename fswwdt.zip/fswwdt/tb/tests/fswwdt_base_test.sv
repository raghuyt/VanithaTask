//-----------------------------------------------------------------------------
// fswwdt_base_test
//  * builds the environment, applies power-on reset, runs main_body()
//  * a global watchdog on the simulation itself (set_timeout) prevents a hung
//    handshake from burning regression slots
//  * report_phase prints a single greppable PASS/FAIL line for regress.sh
//-----------------------------------------------------------------------------
class fswwdt_base_test extends uvm_test;
  `uvm_component_utils(fswwdt_base_test)

  fswwdt_env         env;
  virtual clk_rst_if crif;
  realtime           sim_limit    = 20ms;
  realtime           pclk_period  = 10.0;   // 100 MHz
  realtime           wdt_period   = 40.0;   //  25 MHz
  int unsigned       por_cycles   = 20;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = fswwdt_env::type_id::create("env", this);
    if (!uvm_config_db#(virtual clk_rst_if)::get(this, "", "crif", crif))
      `uvm_fatal("NOVIF", "crif not set by tb_top")
    uvm_root::get().set_timeout(sim_limit, 1);
  endfunction

  function void end_of_elaboration_phase(uvm_phase phase);
    if (uvm_report_enabled(UVM_HIGH)) uvm_top.print_topology();
  endfunction

  // Clock setup happens before POR so cov/sb see the final ratio.
  virtual function void set_clocks();
    crif.set_pclk_period(pclk_period);
    crif.set_wdt_period(wdt_period);
  endfunction

  task run_phase(uvm_phase phase);
    phase.raise_objection(this);
    set_clocks();
    `uvm_info("TEST", $sformatf("POR: pclk=%0.1fns wdt_clk=%0.1fns", crif.pclk_period(),
                                crif.wdt_period()), UVM_LOW)
    crif.apply_reset(por_cycles);            // TP-RST-01 power-on reset
    crif.wait_pclk(10);
    main_body(phase);
    crif.wait_pclk(200);                     // drain: let last CDC transfers land
    phase.drop_objection(this);
  endtask

  virtual task main_body(uvm_phase phase);
  endtask

  // helper: run a sequence on the APB sequencer
  task run(fswwdt_base_seq s);
    s.start(env.apb_agt.sqr);
  endtask

  function void report_phase(uvm_phase phase);
    uvm_report_server rs = uvm_report_server::get_server();
    int unsigned n_err = rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL);
    if (n_err == 0) `uvm_info("TEST", "*** TEST PASSED ***", UVM_NONE)
    else            `uvm_info("TEST", $sformatf("*** TEST FAILED *** (%0d errors)", n_err), UVM_NONE)
  endfunction
endclass : fswwdt_base_test
