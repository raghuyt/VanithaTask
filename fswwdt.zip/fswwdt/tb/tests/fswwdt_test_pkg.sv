package fswwdt_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import fswwdt_pkg::*;
  import apb_agent_pkg::*;
  import wdt_probe_pkg::*;
  import fswwdt_env_pkg::*;
  import fswwdt_seq_pkg::*;

  `include "fswwdt_base_test.sv"
  `include "fswwdt_tests.sv"
endpackage : fswwdt_test_pkg
