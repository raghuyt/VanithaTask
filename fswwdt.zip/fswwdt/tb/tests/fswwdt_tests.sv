//-----------------------------------------------------------------------------
// fswwdt_tests.sv : regression tests. Each test = one or more test-plan IDs.
// Tests only choose *what* to run; checking lives in scoreboard + SVA, so
// every test is self-checking even if its sequence performs no explicit check.
//-----------------------------------------------------------------------------

// Randomize-and-run with optional inline constraint (keeps tests short)
`define FSW_RUN(T, CON) \
  begin \
    T s_ = T::type_id::create(`"T`"); \
    if (!s_.randomize() with CON) `uvm_fatal("RAND", {`"T`", " randomization failed"}) \
    run(s_); \
  end

// TP-REG-01..08 -------------------------------------------------------------
class fswwdt_reg_access_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_reg_access_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    fswwdt_reg_access_seq s = fswwdt_reg_access_seq::type_id::create("s");
    run(s);
  endtask
endclass

// TP-BASIC / TP-TMO : RST_EN=1 (reset) and RST_EN=0 (event only) --------------
class fswwdt_timeout_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_timeout_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    `FSW_RUN(fswwdt_timeout_seq, {rst_en == 1; win_en == 0;})
    `FSW_RUN(fswwdt_timeout_seq, {rst_en == 1; win_en == 1;})
    `FSW_RUN(fswwdt_timeout_seq, {rst_en == 0; win_en == 0;})
    `FSW_RUN(fswwdt_timeout_seq, {rst_en == 0; win_en == 1;})
  endtask
endclass

// TP-WIN : correct servicing, windowed and non-windowed ----------------------
class fswwdt_window_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_window_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    repeat (3) `FSW_RUN(fswwdt_window_service_seq, {win_en == 1;})
    `FSW_RUN(fswwdt_window_service_seq, {win_en == 0;})
  endtask
endclass

// TP-EARLY --------------------------------------------------------------------
class fswwdt_early_kick_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_early_kick_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    `FSW_RUN(fswwdt_early_kick_seq, {rst_en == 0;})
    `FSW_RUN(fswwdt_early_kick_seq, {rst_en == 1;})
  endtask
endclass

// TP-LATE ---------------------------------------------------------------------
class fswwdt_late_kick_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_late_kick_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    `FSW_RUN(fswwdt_late_kick_seq, {win_en == 0;})
    `FSW_RUN(fswwdt_late_kick_seq, {win_en == 1;})
  endtask
endclass

// TP-KEY ----------------------------------------------------------------------
class fswwdt_bad_key_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_bad_key_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    `FSW_RUN(fswwdt_bad_key_seq, {rst_en == 0;})
    `FSW_RUN(fswwdt_bad_key_seq, {rst_en == 1;})
  endtask
endclass

// TP-IRQ ----------------------------------------------------------------------
class fswwdt_ewi_irq_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_ewi_irq_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    `FSW_RUN(fswwdt_ewi_irq_seq, {win_en == 1;})
    `FSW_RUN(fswwdt_ewi_irq_seq, {win_en == 0;})
  endtask
endclass

// TP-LOCK ---------------------------------------------------------------------
class fswwdt_lock_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_lock_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    `FSW_RUN(fswwdt_lock_seq, {win_en == 1;})
  endtask
endclass

// TP-FI : error injection on the redundant counter ---------------------------
class fswwdt_fault_inj_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_fault_inj_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    `FSW_RUN(fswwdt_fault_inj_seq, {rst_en == 0;})
    `FSW_RUN(fswwdt_fault_inj_seq, {rst_en == 1;})
  endtask
endclass

// TP-DBG ----------------------------------------------------------------------
class fswwdt_dbg_freeze_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_dbg_freeze_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    `FSW_RUN(fswwdt_dbg_freeze_seq, {win_en == 1;})
    `FSW_RUN(fswwdt_dbg_freeze_seq, {win_en == 0;})
  endtask
endclass

// TP-CFG : corner configurations ------------------------------------------------
class fswwdt_cfg_corner_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_cfg_corner_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    fswwdt_cfg_corner_seq s = fswwdt_cfg_corner_seq::type_id::create("s");
    run(s);
  endtask
endclass

// TP-CLK-01/02 : watchdog clock stop / start -----------------------------------
class fswwdt_clk_fail_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_clk_fail_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    env.sb.clkfail_allowed = 1;          // CLK_FAIL is the expected outcome here
    `FSW_RUN(fswwdt_clk_fail_seq, {rst_en == 0;})
    `FSW_RUN(fswwdt_clk_fail_seq, {rst_en == 1;})
    env.sb.clkfail_allowed = 0;
    `FSW_RUN(fswwdt_window_service_seq, {win_en == 1;})   // recovered and healthy
  endtask
endclass

// TP-CLK-03 : bus clock stop -> watchdog resets the system --------------------
class fswwdt_pclk_stop_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_pclk_stop_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    `FSW_RUN(fswwdt_pclk_stop_seq, {win_en == 1;})
    `FSW_RUN(fswwdt_window_service_seq, {win_en == 1;})
  endtask
endclass

// TP-CLK-04 : clock ratio sweep (reconfigured while disabled + reset) ----------
class fswwdt_clk_ratio_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_clk_ratio_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    realtime wdt_p[$] = '{40.0, 80.0, 200.0, 400.0};   // ratio 4, 8, 20, 40 (< CLKMON_LIMIT)
    foreach (wdt_p[i]) begin
      crif.set_wdt_period(wdt_p[i]);
      crif.apply_reset(10);                            // warm reset between points
      crif.wait_pclk(10);
      `uvm_info("TEST", $sformatf("ratio point wdt=%0.1fns", wdt_p[i]), UVM_LOW)
      `FSW_RUN(fswwdt_window_service_seq, {win_en == 1;})
      `FSW_RUN(fswwdt_timeout_seq,        {rst_en == 1;})
    end
  endtask
endclass

// TP-CLK-05 : frequency variation while running --------------------------------
class fswwdt_clk_freq_change_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_clk_freq_change_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    `FSW_RUN(fswwdt_clk_freq_change_seq, {timeout inside {[300:600]};})
  endtask
endclass

// TP-RST-02..05 : warm / async / sync reset during operation --------------------
class fswwdt_reset_during_run_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_reset_during_run_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    repeat (4) `FSW_RUN(fswwdt_reset_mid_seq, {sync_rst == 0;})
    repeat (4) `FSW_RUN(fswwdt_reset_mid_seq, {sync_rst == 1;})
    `FSW_RUN(fswwdt_window_service_seq, {win_en == 1;})
  endtask
endclass

// TP-RST-06/07 : reset during timeout condition, BITE and HALT -------------------
class fswwdt_reset_during_bite_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_reset_during_bite_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  task main_body(uvm_phase phase);
    repeat (2) `FSW_RUN(fswwdt_reset_bite_seq, {where == fswwdt_reset_bite_seq::AT_TIMEOUT;})
    repeat (2) `FSW_RUN(fswwdt_reset_bite_seq, {where == fswwdt_reset_bite_seq::IN_BITE;})
    repeat (2) `FSW_RUN(fswwdt_reset_bite_seq, {where == fswwdt_reset_bite_seq::IN_HALT;})
    `FSW_RUN(fswwdt_window_service_seq, {win_en == 1;})
  endtask
endclass

// TP-RAND : constrained-random mix, random clock ratio per seed ------------------
class fswwdt_random_test extends fswwdt_base_test;
  `uvm_component_utils(fswwdt_random_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  function void set_clocks();
    wdt_period = 10.0 * $urandom_range(4, 30);         // legal ratio range
    super.set_clocks();
  endfunction
  task main_body(uvm_phase phase);
    repeat (5) begin
      fswwdt_rand_seq s = fswwdt_rand_seq::type_id::create("s");
      if (!s.randomize()) `uvm_fatal("RAND", "rand_seq randomization failed")
      run(s);
    end
  endtask
endclass
