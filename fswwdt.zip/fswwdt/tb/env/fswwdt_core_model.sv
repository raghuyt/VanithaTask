//-----------------------------------------------------------------------------
// fswwdt_core_model : cycle-accurate transaction-level reference model of the
// watchdog core. step() consumes the pre-edge inputs of one wdt_clk cycle and
// advances the predicted state to what the DUT registers at that edge.
// Written from the specification (docs/), not copied from RTL.
//-----------------------------------------------------------------------------
class fswwdt_core_model;
  int unsigned        rst_len;
  wdt_state_e         st;
  bit [CNT_W-1:0]     cnt, cnt_n;
  int unsigned        bite;
  bit                 fi_q;
  bit [NUM_EVT-1:0]   evt;
  bit                 rst_req;
  // classification of the last step (debug / coverage)
  bit                 last_fault, last_kick_ok;

  function new(int unsigned rst_len = 16);
    this.rst_len = rst_len;
    reset();
  endfunction

  function void reset();
    st = ST_DISABLED; cnt = '0; cnt_n = '1; bite = 0;
    fi_q = 0; evt = '0; rst_req = 0; last_fault = 0; last_kick_ok = 0;
  endfunction

  // re-align after a reported mismatch so one bug does not flood the log
  function void sync(wdt_core_txn t);
    st = t.state; cnt = t.cnt; cnt_n = t.cnt_n; evt = t.evt; rst_req = t.rst_req;
  endfunction

  function void step(wdt_core_txn t);
    wdt_cfg_t       c;
    bit             running, tick, cnterr, tmo, ewi, early, key, kick_ok, fault;
    bit [CNT_W-1:0] inc, ncnt, ncn;
    wdt_state_e     rs, nst;
    int unsigned    nbite;

    c       = t.cfg;
    running = (st == ST_CLOSED) || (st == ST_OPEN);
    tick    = running && !(c.dbg_frz && t.dbg_halt);
    inc     = cnt + 1;
    cnterr  = running && (cnt != ~cnt_n);
    tmo     = tick && (inc == c.timeout);
    ewi     = tick && (c.ewi != 0) && (inc == c.ewi);
    early   = running && t.kick_good && (st == ST_CLOSED);
    key     = running && t.kick_bad;
    kick_ok = running && t.kick_good && (st == ST_OPEN);
    fault   = cnterr || tmo || early || key;
    rs      = (!c.win_en || (c.window == 0)) ? ST_OPEN : ST_CLOSED;

    nst = st; ncnt = cnt; ncn = cnt_n; nbite = bite;

    case (st)
      ST_DISABLED: if (c.en) begin nst = rs; ncnt = 0; ncn = '1; end
      ST_CLOSED, ST_OPEN: begin
        if (fault) begin
          ncnt = 0; ncn = '1;
          if (c.rst_en) begin nst = ST_BITE; nbite = rst_len - 1; end
          else            nst = rs;
        end else if (!c.en) begin
          nst = ST_DISABLED; ncnt = 0; ncn = '1;
        end else if (kick_ok) begin
          nst = rs; ncnt = 0; ncn = '1;
        end else if (tick) begin
          ncnt = inc; ncn = ~inc;
          if ((st == ST_CLOSED) && (inc >= c.window)) nst = ST_OPEN;
        end
        if ((c.fi && !fi_q) && ((nst == ST_CLOSED) || (nst == ST_OPEN))) ncn[0] = ~ncn[0];
      end
      ST_BITE: if (bite == 0) nst = ST_HALT; else nbite = bite - 1;
      ST_HALT: ;
      default: begin nst = ST_BITE; nbite = rst_len - 1; ncnt = 0; ncn = '1; end
    endcase

    evt          = '0;
    evt[EVT_EWI]    = ewi;
    evt[EVT_TMO]    = tmo;
    evt[EVT_EARLY]  = early;
    evt[EVT_CNTERR] = cnterr;
    rst_req      = (nst == ST_BITE);
    last_fault   = fault;
    last_kick_ok = kick_ok && !fault;
    st = nst; cnt = ncnt; cnt_n = ncn; bite = nbite; fi_q = c.fi;
  endfunction
endclass : fswwdt_core_model
