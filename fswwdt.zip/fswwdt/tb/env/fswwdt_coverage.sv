//-----------------------------------------------------------------------------
// fswwdt_coverage : functional coverage model (spec-derived)
//-----------------------------------------------------------------------------
class fswwdt_coverage extends uvm_component;
  `uvm_component_utils(fswwdt_coverage)

  typedef enum {K_EARLY, K_IN_WINDOW, K_BAD_RUNNING, K_WHILE_DISABLED, K_WHILE_BITE_HALT} kick_kind_e;
  typedef enum {F_TMO, F_EARLY, F_KEY, F_CNTERR} fault_kind_e;

  uvm_analysis_imp_apb  #(apb_seq_item, fswwdt_coverage) apb_imp;
  uvm_analysis_imp_core #(wdt_core_txn, fswwdt_coverage) core_imp;
  virtual clk_rst_if crif;

  apb_seq_item      tr;
  wdt_state_e       st, prev_st;
  bit               prev_rst_n, prev_rst_en;
  bit [CNT_W-1:0]   sh_timeout = TIMEOUT_RST, sh_window, sh_ewi;

  // ---------------- register access ---------------------------------------
  covergroup cg_reg;
    option.per_instance = 1;
    cp_addr: coverpoint tr.addr {
      bins ctrl     = {ADDR_CTRL};     bins timeout  = {ADDR_TIMEOUT};
      bins window   = {ADDR_WINDOW};   bins ewi      = {ADDR_EWI};
      bins kick     = {ADDR_KICK};     bins status   = {ADDR_STATUS};
      bins irq_en   = {ADDR_IRQ_EN};   bins count    = {ADDR_COUNT};
      bins fault_inj= {ADDR_FAULT_INJ};bins id       = {ADDR_ID};
      bins unmapped = {[12'h028:12'hFFC]};
      wildcard bins misaligned = {12'b???????????1, 12'b??????????1?};
    }
    cp_dir: coverpoint tr.write  { bins rd = {0}; bins wr = {1}; }
    cp_err: coverpoint tr.slverr { bins ok = {0}; bins err = {1}; }
    x_access: cross cp_addr, cp_dir, cp_err {
      // reads of mapped registers never error
      ignore_bins rd_mapped_err = binsof(cp_dir.rd) && binsof(cp_err.err) &&
                                  !binsof(cp_addr.unmapped) && !binsof(cp_addr.misaligned);
      // unmapped / misaligned accesses always error
      ignore_bins unmapped_ok   = (binsof(cp_addr.unmapped) || binsof(cp_addr.misaligned)) &&
                                  binsof(cp_err.ok);
      // RO registers always error on write
      ignore_bins ro_wr_ok      = (binsof(cp_addr.count) || binsof(cp_addr.id)) &&
                                  binsof(cp_dir.wr) && binsof(cp_err.ok);
      // STATUS / IRQ_EN writes never error
      ignore_bins rw_wr_err     = (binsof(cp_addr.status) || binsof(cp_addr.irq_en)) &&
                                  binsof(cp_dir.wr) && binsof(cp_err.err);
    }
  endgroup

  // ---------------- CTRL programming (accepted writes) --------------------
  covergroup cg_ctrl;
    option.per_instance = 1;
    cp_en:      coverpoint tr.wdata[CTRL_EN];
    cp_win_en:  coverpoint tr.wdata[CTRL_WIN_EN];
    cp_rst_en:  coverpoint tr.wdata[CTRL_RST_EN];
    cp_dbg_frz: coverpoint tr.wdata[CTRL_DBG_FRZ];
    cp_lock:    coverpoint tr.wdata[CTRL_LOCK];
    x_mode:     cross cp_en, cp_win_en, cp_rst_en;
    x_lock_en:  cross cp_lock, cp_en;
  endgroup

  // ---------------- configuration at enable -------------------------------
  covergroup cg_cfg with function sample(bit [CNT_W-1:0] to, int unsigned win_pct,
                                         bit win_en, bit ewi_on, int unsigned clk_ratio);
    option.per_instance = 1;
    cp_timeout: coverpoint to {
      bins tiny  = {[1:3]};           bins small = {[4:255]};
      bins mid   = {[256:65535]};     bins large = {[65536:32'hFFFF_FFFE]};
      bins max   = {32'hFFFF_FFFF};
    }
    cp_win_pct: coverpoint win_pct iff (win_en) {
      bins zero = {0}; bins low = {[1:25]}; bins mid = {[26:75]}; bins high = {[76:99]};
    }
    cp_win_en:  coverpoint win_en;
    cp_ewi:     coverpoint ewi_on;
    cp_ratio:   coverpoint clk_ratio {        // wdt_period / pclk_period
      // ratio < 4 violates the clock-monitor sampling requirement (spec 5.4):
      // not a legal operating point, so it is excluded rather than left as a hole.
      ignore_bins r_1_3 = {[1:3]};  bins r_4_8 = {[4:8]};
      bins r_9_32  = {[9:32]};  bins r_gt32 = {[33:$]};
    }
    x_win_to:   cross cp_win_pct, cp_timeout {
      // with TIMEOUT <= 3 the only reachable window ratios are 0/33/50/66 %
      ignore_bins tiny_unreach = binsof(cp_timeout.tiny) &&
                                 (binsof(cp_win_pct.low) || binsof(cp_win_pct.high));
    }
    x_ewi_win:  cross cp_ewi, cp_win_en;
  endgroup

  // ---------------- core FSM ------------------------------------------------
  covergroup cg_fsm;
    option.per_instance = 1;
    cp_state: coverpoint st;
    cp_trans: coverpoint st {
      bins dis_to_closed   = (ST_DISABLED => ST_CLOSED);
      bins dis_to_open     = (ST_DISABLED => ST_OPEN);
      bins closed_to_open  = (ST_CLOSED   => ST_OPEN);
      bins open_to_closed  = (ST_OPEN     => ST_CLOSED);     // kick with window
      bins closed_to_bite  = (ST_CLOSED   => ST_BITE);
      bins open_to_bite    = (ST_OPEN     => ST_BITE);
      bins bite_to_halt    = (ST_BITE     => ST_HALT);
      bins closed_to_dis   = (ST_CLOSED   => ST_DISABLED);
      bins open_to_dis     = (ST_OPEN     => ST_DISABLED);
      bins full_period     = (ST_DISABLED => ST_CLOSED => ST_OPEN);
    }
  endgroup

  // ---------------- faults ----------------------------------------------------
  covergroup cg_fault with function sample(fault_kind_e k, wdt_state_e s, bit rst_en);
    option.per_instance = 1;
    cp_kind:   coverpoint k;
    cp_state:  coverpoint s { bins closed = {ST_CLOSED}; bins open = {ST_OPEN}; }
    cp_rst_en: coverpoint rst_en;
    x_kind_rst:   cross cp_kind, cp_rst_en;
    x_kind_state: cross cp_kind, cp_state {
      ignore_bins early_in_open = binsof(cp_kind) intersect {F_EARLY} && binsof(cp_state.open);
    }
  endgroup

  // ---------------- kick outcomes ---------------------------------------------
  covergroup cg_kick with function sample(kick_kind_e k, bit win_en);
    option.per_instance = 1;
    cp_kind:   coverpoint k;
    cp_win_en: coverpoint win_en;
    x_kind_win: cross cp_kind, cp_win_en {
      ignore_bins early_no_win = binsof(cp_kind) intersect {K_EARLY} && binsof(cp_win_en) intersect {0};
    }
  endgroup

  // ---------------- reset in every state ------------------------------------
  covergroup cg_reset with function sample(wdt_state_e s);
    option.per_instance = 1;
    cp_state_at_reset: coverpoint s;
  endgroup

  // ---------------- debug freeze -----------------------------------------------
  covergroup cg_dbg with function sample(wdt_state_e s);
    option.per_instance = 1;
    cp_frozen_in: coverpoint s { bins closed = {ST_CLOSED}; bins open = {ST_OPEN}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_reg   = new();
    cg_ctrl  = new();
    cg_cfg   = new();
    cg_fsm   = new();
    cg_fault = new();
    cg_kick  = new();
    cg_reset = new();
    cg_dbg   = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    apb_imp  = new("apb_imp",  this);
    core_imp = new("core_imp", this);
    if (!uvm_config_db#(virtual clk_rst_if)::get(this, "", "crif", crif))
      `uvm_fatal("NOVIF", "crif not set")
  endfunction

  task run_phase(uvm_phase phase);
    forever begin
      @(negedge crif.presetn);
      sh_timeout = TIMEOUT_RST; sh_window = 0; sh_ewi = 0;
    end
  endtask

  function void write_apb(apb_seq_item t);
    int unsigned ratio, pct;
    tr = t;
    cg_reg.sample();
    if (!t.write || t.slverr) return;
    case (t.addr)
      ADDR_TIMEOUT: sh_timeout = t.wdata;
      ADDR_WINDOW:  sh_window  = t.wdata;
      ADDR_EWI:     sh_ewi     = t.wdata;
      ADDR_CTRL: begin
        cg_ctrl.sample();
        if (t.wdata[CTRL_EN]) begin
          ratio = int'(crif.wdt_period() / crif.pclk_period());
          pct   = (sh_timeout == 0) ? 0 : int'((64'(sh_window) * 100) / sh_timeout);
          cg_cfg.sample(sh_timeout, pct, t.wdata[CTRL_WIN_EN], (sh_ewi != 0), ratio);
        end
      end
      default: ;
    endcase
  endfunction

  function void write_core(wdt_core_txn t);
    bit running;
    if (!t.rst_n) begin
      if (prev_rst_n) cg_reset.sample(prev_st);
      prev_rst_n = 0;
      return;
    end
    st      = t.state;
    running = (st == ST_CLOSED) || (st == ST_OPEN);
    cg_fsm.sample();

    // events are registered: they belong to the previous sample's state
    if (t.evt[EVT_TMO])    cg_fault.sample(F_TMO,    prev_st, prev_rst_en);
    if (t.evt[EVT_EARLY])  cg_fault.sample(F_EARLY,  prev_st, prev_rst_en);
    if (t.evt[EVT_CNTERR]) cg_fault.sample(F_CNTERR, prev_st, prev_rst_en);
    if (t.kick_bad && running) cg_fault.sample(F_KEY, st, t.cfg.rst_en);

    if (t.kick_good) begin
      case (st)
        ST_CLOSED:   cg_kick.sample(K_EARLY,           t.cfg.win_en);
        ST_OPEN:     cg_kick.sample(K_IN_WINDOW,       t.cfg.win_en);
        ST_DISABLED: cg_kick.sample(K_WHILE_DISABLED,  t.cfg.win_en);
        default:     cg_kick.sample(K_WHILE_BITE_HALT, t.cfg.win_en);
      endcase
    end
    if (t.kick_bad && running) cg_kick.sample(K_BAD_RUNNING, t.cfg.win_en);

    if (running && t.cfg.dbg_frz && t.dbg_halt) cg_dbg.sample(st);

    prev_st     = st;
    prev_rst_n  = 1;
    prev_rst_en = t.cfg.rst_en;
  endfunction
endclass : fswwdt_coverage
