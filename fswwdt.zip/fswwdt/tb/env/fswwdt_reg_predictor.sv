//-----------------------------------------------------------------------------
// fswwdt_reg_predictor : mirror of the programmer's-model registers and the
// PSLVERR rules. Kept deliberately simple and spec-driven.
//-----------------------------------------------------------------------------
class fswwdt_reg_predictor;
  bit                   en, win_en, rst_en, dbg_frz, lock, fi;
  bit [CNT_W-1:0]       timeout, window, ewi;
  bit [NUM_FLAGS-1:0]   irq_en;

  function new(); reset(); endfunction

  function void reset();
    en = 0; win_en = 0; rst_en = 0; dbg_frz = 0; lock = 0; fi = 0;
    timeout = TIMEOUT_RST; window = 0; ewi = 0; irq_en = 0;
  endfunction

  function bit is_cfg_addr(bit [ADDR_W-1:0] a);
    return a inside {ADDR_CTRL, ADDR_TIMEOUT, ADDR_WINDOW, ADDR_EWI, ADDR_FAULT_INJ};
  endfunction

  function bit exp_wr_err(apb_seq_item t);
    case (t.addr)
      ADDR_CTRL:      return lock || t.cfg_pend ||
                             (t.wdata[CTRL_EN] && !cfg_legal(t.wdata[CTRL_WIN_EN], timeout, window, ewi)) ||
                             (en && (t.wdata[CTRL_WIN_EN] != win_en));
      ADDR_TIMEOUT,
      ADDR_WINDOW,
      ADDR_EWI:       return lock || en || t.cfg_pend;
      ADDR_FAULT_INJ: return lock || t.cfg_pend;
      ADDR_KICK:      return t.kick_pend;
      ADDR_STATUS,
      ADDR_IRQ_EN:    return 0;
      default:        return 1;
    endcase
  endfunction

  function bit exp_rd_err(bit [ADDR_W-1:0] a);
    return !(a inside {ADDR_CTRL, ADDR_TIMEOUT, ADDR_WINDOW, ADDR_EWI, ADDR_KICK,
                       ADDR_STATUS, ADDR_IRQ_EN, ADDR_COUNT, ADDR_FAULT_INJ, ADDR_ID});
  endfunction

  function void commit(apb_seq_item t);
    case (t.addr)
      ADDR_CTRL: begin
        en      = t.wdata[CTRL_EN];     win_en  = t.wdata[CTRL_WIN_EN];
        rst_en  = t.wdata[CTRL_RST_EN]; dbg_frz = t.wdata[CTRL_DBG_FRZ];
        lock    = lock | t.wdata[CTRL_LOCK];
      end
      ADDR_TIMEOUT:   timeout = t.wdata;
      ADDR_WINDOW:    window  = t.wdata;
      ADDR_EWI:       ewi     = t.wdata;
      ADDR_IRQ_EN:    irq_en  = t.wdata[NUM_FLAGS-1:0];
      ADDR_FAULT_INJ: fi      = t.wdata[0];
      default: ;
    endcase
  endfunction

  // expected read data for registers with fully predictable content
  function bit [31:0] exp_rdata(bit [ADDR_W-1:0] a);
    bit [31:0] d = '0;
    case (a)
      ADDR_CTRL: begin
        d[CTRL_EN] = en; d[CTRL_WIN_EN] = win_en; d[CTRL_RST_EN] = rst_en;
        d[CTRL_DBG_FRZ] = dbg_frz; d[CTRL_LOCK] = lock;
      end
      ADDR_TIMEOUT:   d = timeout;
      ADDR_WINDOW:    d = window;
      ADDR_EWI:       d = ewi;
      ADDR_IRQ_EN:    d[NUM_FLAGS-1:0] = irq_en;
      ADDR_FAULT_INJ: d[0] = fi;
      ADDR_ID:        d = ID_VALUE;
      default:        d = '0;          // KICK reads as zero
    endcase
    return d;
  endfunction

  function wdt_cfg_t get_cfg();
    wdt_cfg_t c;
    c.fi = fi; c.dbg_frz = dbg_frz; c.rst_en = rst_en; c.win_en = win_en; c.en = en;
    c.ewi = ewi; c.window = window; c.timeout = timeout;
    return c;
  endfunction
endclass : fswwdt_reg_predictor
