class fswwdt_env extends uvm_env;
  `uvm_component_utils(fswwdt_env)

  apb_agent         apb_agt;
  wdt_probe_agent   prb_agt;
  fswwdt_scoreboard sb;
  fswwdt_coverage   cov;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    apb_agt = apb_agent::type_id::create("apb_agt", this);
    prb_agt = wdt_probe_agent::type_id::create("prb_agt", this);
    sb      = fswwdt_scoreboard::type_id::create("sb", this);
    cov     = fswwdt_coverage::type_id::create("cov", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    apb_agt.mon.ap.connect(sb.apb_imp);
    apb_agt.mon.ap.connect(cov.apb_imp);
    prb_agt.mon.ap.connect(sb.core_imp);
    prb_agt.mon.ap.connect(cov.core_imp);
  endfunction
endclass : fswwdt_env
