//-----------------------------------------------------------------------------
// fswwdt_scoreboard
//  Check 1: APB register predictor (read data + PSLVERR, exact)
//  Check 2: cycle-accurate core reference model vs. white-box probe
//  Check 3: configuration delivered across CDC == committed register values
//  Check 4: kick accounting - no lost / duplicated / spurious kicks
//  Check 5: STATUS flags - no spurious flag, no flag missing after max latency
//-----------------------------------------------------------------------------
class fswwdt_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(fswwdt_scoreboard)

  uvm_analysis_imp_apb  #(apb_seq_item, fswwdt_scoreboard) apb_imp;
  uvm_analysis_imp_core #(wdt_core_txn, fswwdt_scoreboard) core_imp;

  virtual clk_rst_if     crif;
  fswwdt_reg_predictor   pred;
  fswwdt_core_model      model;
  int unsigned           rst_len = 16;

  // knobs set by tests
  bit                    clkfail_allowed = 0;

  // check 3
  wdt_cfg_t              cfg_hist[$];
  int unsigned           hist_idx;
  wdt_cfg_t              last_core_cfg;
  // check 4
  int unsigned           n_apb_good, n_apb_bad, n_core_good, n_core_bad;
  // check 5
  bit                    cause_valid [NUM_FLAGS];
  realtime               last_cause  [NUM_FLAGS];
  realtime               last_clear  [NUM_FLAGS];
  // statistics
  int unsigned           n_core_samples, n_apb_checked, n_faults_seen, n_bites_seen;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    apb_imp  = new("apb_imp",  this);
    core_imp = new("core_imp", this);
    if (!uvm_config_db#(virtual clk_rst_if)::get(this, "", "crif", crif))
      `uvm_fatal("NOVIF", "crif not set")
    void'(uvm_config_db#(int unsigned)::get(this, "", "rst_len", rst_len));
    pred  = new();
    model = new(rst_len);
    reset_all();
  endfunction

  task run_phase(uvm_phase phase);
    forever begin
      @(negedge crif.presetn);
      `uvm_info("SB", "reset observed - clearing scoreboard state", UVM_MEDIUM)
      reset_all();
    end
  endtask

  function void reset_all();
    pred.reset();
    cfg_hist.delete();
    hist_idx      = 0;
    last_core_cfg = '0;
    n_apb_good = 0; n_apb_bad = 0; n_core_good = 0; n_core_bad = 0;
    foreach (cause_valid[i]) begin cause_valid[i] = 0; last_cause[i] = 0; last_clear[i] = 0; end
  endfunction

  // ======================= APB side =========================================
  function void write_apb(apb_seq_item t);
    bit exp_err;
    n_apb_checked++;
    if (t.write) begin
      exp_err = pred.exp_wr_err(t);
      if (t.slverr !== exp_err)
        `uvm_error("SB_APB", $sformatf("PSLVERR mismatch exp=%0b : %s", exp_err, t.convert2string()))
      if (!t.slverr) begin
        pred.commit(t);
        if (pred.is_cfg_addr(t.addr)) cfg_hist.push_back(pred.get_cfg());
        if (t.addr == ADDR_KICK) begin
          if (t.wdata == KICK_KEY) n_apb_good++;
          else begin n_apb_bad++; note_cause(FLG_KEYERR); end
        end
        if (t.addr == ADDR_STATUS) note_clear(t.wdata[NUM_FLAGS-1:0]);
      end
    end else begin
      exp_err = pred.exp_rd_err(t.addr);
      if (t.slverr !== exp_err)
        `uvm_error("SB_APB", $sformatf("PSLVERR mismatch exp=%0b : %s", exp_err, t.convert2string()))
      else if (!t.slverr) begin
        case (t.addr)
          ADDR_STATUS: check_status(t.rdata);
          ADDR_COUNT:  ;   // asynchronous snapshot - checked via core model instead
          default:
            if (t.rdata !== pred.exp_rdata(t.addr))
              `uvm_error("SB_APB", $sformatf("RDATA mismatch exp=0x%08h : %s",
                                             pred.exp_rdata(t.addr), t.convert2string()))
        endcase
      end
    end
  endfunction

  function void note_cause(int unsigned i);
    cause_valid[i] = 1;
    last_cause[i]  = $realtime;
  endfunction

  function void note_clear(bit [NUM_FLAGS-1:0] m);
    foreach (last_clear[i]) if (m[i]) last_clear[i] = $realtime;
  endfunction

  function void check_status(bit [31:0] d);
    realtime lat = 12.0 * crif.wdt_period() + 12.0 * crif.pclk_period();
    if (d[STS_LOCKED] !== pred.lock)
      `uvm_error("SB_STS", $sformatf("LOCKED bit %0b, expected %0b", d[STS_LOCKED], pred.lock))
    if (d[STS_STATE_LSB +: 3] > 3'd4)
      `uvm_error("SB_STS", $sformatf("illegal STATE %0d in STATUS", d[STS_STATE_LSB +: 3]))
    for (int i = 0; i < NUM_FLAGS; i++) begin
      if (i == FLG_CLKFAIL) begin
        if (d[i] && !clkfail_allowed) `uvm_error("SB_STS", "unexpected CLK_FAIL flag")
        continue;
      end
      if (d[i]) begin
        if (!cause_valid[i] || (last_cause[i] < (last_clear[i] - lat)))
          `uvm_error("SB_STS", $sformatf("spurious flag bit %0d set (STATUS=0x%08h)", i, d))
      end else begin
        if (cause_valid[i] && (last_cause[i] > last_clear[i]) && (($realtime - last_cause[i]) > lat))
          `uvm_error("SB_STS", $sformatf("flag bit %0d missing: cause at %0t (STATUS=0x%08h)",
                                         i, last_cause[i], d))
      end
    end
  endfunction

  // ======================= core side ========================================
  function void write_core(wdt_core_txn t);
    if (!t.rst_n) begin
      model.reset();
      return;
    end
    n_core_samples++;

    // Check 2 : reference model
    if ((t.state != model.st) || (t.cnt != model.cnt) || (t.cnt_n != model.cnt_n) ||
        (t.evt != model.evt) || (t.rst_req != model.rst_req)) begin
      `uvm_error("SB_CORE", $sformatf("model mismatch\n  DUT  : %s\n  MODEL: st=%s cnt=%0d cnt_n=0x%08h evt=%04b rst_req=%0b",
                 t.convert2string(), model.st.name(), model.cnt, model.cnt_n, model.evt, model.rst_req))
      model.sync(t);
    end

    // Check 3 : configuration delivery
    if (t.cfg !== last_core_cfg) begin
      check_cfg_delivery(t.cfg);
      last_core_cfg = t.cfg;
    end

    // Check 4 : kick accounting
    if (t.kick_good) begin
      n_core_good++;
      if (n_core_good > n_apb_good) `uvm_error("SB_KICK", "core received a good kick that was never issued")
    end
    if (t.kick_bad) begin
      n_core_bad++;
      if (n_core_bad > n_apb_bad) `uvm_error("SB_KICK", "core received a bad kick that was never issued")
    end

    // Check 5 : record flag causes
    if (t.evt[EVT_EWI])    note_cause(FLG_EWI);
    if (t.evt[EVT_TMO])    note_cause(FLG_TMO);
    if (t.evt[EVT_EARLY])  note_cause(FLG_EARLY);
    if (t.evt[EVT_CNTERR]) note_cause(FLG_CNTERR);

    model.step(t);
    if (model.last_fault)       n_faults_seen++;
    if (model.st == ST_BITE && t.state != ST_BITE) n_bites_seen++;
  endfunction

  function void check_cfg_delivery(wdt_cfg_t c);
    for (int j = hist_idx; j < cfg_hist.size(); j++) begin
      if (cfg_hist[j] == c) begin hist_idx = j; return; end
    end
    `uvm_error("SB_CFG", $sformatf("core received configuration never committed on APB: en=%0b win_en=%0b rst_en=%0b to=%0d win=%0d ewi=%0d",
                                   c.en, c.win_en, c.rst_en, c.timeout, c.window, c.ewi))
  endfunction

  function void check_phase(uvm_phase phase);
    if ((int'(n_apb_good) - int'(n_core_good)) > 1 || (int'(n_apb_bad) - int'(n_core_bad)) > 1)
      `uvm_error("SB_KICK", $sformatf("kicks lost: apb good/bad=%0d/%0d core good/bad=%0d/%0d",
                                      n_apb_good, n_apb_bad, n_core_good, n_core_bad))
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("SB", $sformatf("core samples=%0d apb checked=%0d faults=%0d bites=%0d",
                              n_core_samples, n_apb_checked, n_faults_seen, n_bites_seen), UVM_LOW)
  endfunction
endclass : fswwdt_scoreboard
