package fswwdt_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import fswwdt_pkg::*;
  import apb_agent_pkg::*;
  import wdt_probe_pkg::*;

  `uvm_analysis_imp_decl(_apb)
  `uvm_analysis_imp_decl(_core)

  `include "fswwdt_core_model.sv"
  `include "fswwdt_reg_predictor.sv"
  `include "fswwdt_scoreboard.sv"
  `include "fswwdt_coverage.sv"
  `include "fswwdt_env.sv"
endpackage : fswwdt_env_pkg
