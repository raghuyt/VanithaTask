//-----------------------------------------------------------------------------
// clk_rst_if.sv : clock generation, reset control and misc TB stimulus.
// Clocks are generated here so tests can change frequency and stop/start
// clocks at run time (clock-variation and clock-loss scenarios).
//-----------------------------------------------------------------------------
interface clk_rst_if;
  timeunit 1ns;
  timeprecision 1ps;

  logic pclk      = 1'b0;
  logic wdt_clk   = 1'b0;
  logic presetn   = 1'b0;
  logic dbg_halt  = 1'b0;
  logic scan_mode = 1'b0;
  logic wdt_rst_req;          // observed DUT output (assigned in tb_top)
  logic wdt_irq;              // observed DUT output

  realtime     pclk_half         = 5.0;   // 100 MHz
  realtime     wdt_half          = 20.0;  //  25 MHz
  bit          pclk_run          = 1'b1;
  bit          wdt_run           = 1'b1;
  bit          auto_reset_en     = 1'b1;  // reset-controller model reacts to wdt_rst_req
  realtime     rstc_delay        = 50.0;  // reset-controller reaction time
  int unsigned rstc_pulse_cycles = 8;
  int unsigned rst_req_count     = 0;   // wdt_rst_req rising edges
  int unsigned reset_count       = 0;   // resets applied (any source)

  initial forever begin #(pclk_half);  if (pclk_run) pclk    = ~pclk;    end
  initial forever begin #(wdt_half);   if (wdt_run)  wdt_clk = ~wdt_clk; end

  function automatic void set_pclk_period(realtime p); pclk_half = p / 2.0; endfunction
  function automatic void set_wdt_period (realtime p); wdt_half  = p / 2.0; endfunction
  function automatic realtime pclk_period(); return 2.0 * pclk_half; endfunction
  function automatic realtime wdt_period();  return 2.0 * wdt_half;  endfunction

  // Asynchronous reset: asserted immediately, released after 'cycles' pclk
  // periods of wall time (works even when a clock is stopped).
  task automatic apply_reset(int unsigned cycles = 10);
    reset_count++;
    presetn = 1'b0;
    #(cycles * pclk_period());
    presetn = 1'b1;
  endtask

  // Reset asserted and released aligned to pclk edges ("synchronous" style)
  task automatic apply_sync_reset(int unsigned cycles = 10);
    @(posedge pclk); reset_count++; presetn <= 1'b0;
    repeat (cycles) @(posedge pclk);
    presetn <= 1'b1;
  endtask

  task automatic wait_pclk(int unsigned n = 1); repeat (n) @(posedge pclk);    endtask
  task automatic wait_wdt (int unsigned n = 1); repeat (n) @(posedge wdt_clk); endtask
endinterface : clk_rst_if
