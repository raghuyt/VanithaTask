//-----------------------------------------------------------------------------
// apb_if.sv : APB3 interface with driver/monitor clocking blocks.
// cfg_pend/kick_pend are white-box probes (driven from tb_top) so the
// register predictor can model the timing-dependent PSLVERR rules exactly.
//-----------------------------------------------------------------------------
interface apb_if (input logic pclk, input logic presetn);
  timeunit 1ns;
  timeprecision 1ps;

  logic        psel    = 1'b0;
  logic        penable = 1'b0;
  logic        pwrite  = 1'b0;
  logic [11:0] paddr   = '0;
  logic [31:0] pwdata  = '0;
  logic [31:0] prdata;
  logic        pready;
  logic        pslverr;
  logic        cfg_pend;     // probe
  logic        kick_pend;    // probe

  clocking drv_cb @(posedge pclk);
    default input #1step output #1;
    output psel, penable, pwrite, paddr, pwdata;
    input  prdata, pready, pslverr;
  endclocking

  clocking mon_cb @(posedge pclk);
    default input #1step;
    input presetn, psel, penable, pwrite, paddr, pwdata, prdata, pready, pslverr,
          cfg_pend, kick_pend;
  endclocking

  modport drv_mp (clocking drv_cb, input presetn, pclk);
  modport mon_mp (clocking mon_cb, input presetn, pclk);
endinterface : apb_if
