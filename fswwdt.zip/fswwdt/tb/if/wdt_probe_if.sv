//-----------------------------------------------------------------------------
// wdt_probe_if.sv : white-box probe of the watchdog core (wdt_clk domain).
// Sampled once per wdt_clk edge; feeds the cycle-accurate reference model.
//-----------------------------------------------------------------------------
interface wdt_probe_if (input logic wdt_clk);
  timeunit 1ns;
  timeprecision 1ps;
  import fswwdt_pkg::*;

  logic               wrst_n;
  wdt_cfg_t           cfg;
  logic               kick_good, kick_bad, dbg_halt;
  wdt_state_e         state;
  logic [CNT_W-1:0]   cnt, cnt_n;
  logic [NUM_EVT-1:0] evt;
  logic               rst_req;

  clocking mon_cb @(posedge wdt_clk);
    default input #1step;
    input wrst_n, cfg, kick_good, kick_bad, dbg_halt, state, cnt, cnt_n, evt, rst_req;
  endclocking
endinterface : wdt_probe_if
