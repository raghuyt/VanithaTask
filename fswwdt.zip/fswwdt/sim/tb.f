// Testbench file list. Paths relative to sim/.
+incdir+../tb/agents/apb
+incdir+../tb/agents/wdt_probe
+incdir+../tb/env
+incdir+../tb/seq
+incdir+../tb/tests
../tb/if/clk_rst_if.sv
../tb/if/apb_if.sv
../tb/if/wdt_probe_if.sv
../tb/agents/apb/apb_agent_pkg.sv
../tb/agents/wdt_probe/wdt_probe_pkg.sv
../tb/env/fswwdt_env_pkg.sv
../tb/seq/fswwdt_seq_pkg.sv
../tb/tests/fswwdt_test_pkg.sv
../tb/sva/fswwdt_core_sva.sv
../tb/sva/fswwdt_top_sva.sv
../tb/sva/fswwdt_bind.sv
../tb/top/tb_top.sv
