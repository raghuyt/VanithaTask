// RTL file list (compile order matters: package first). Paths relative to sim/.
../rtl/fswwdt_pkg.sv
../rtl/fswwdt_sync_cell.sv
../rtl/fswwdt_rst_sync.sv
../rtl/fswwdt_hs_sync.sv
../rtl/fswwdt_evt_sync.sv
../rtl/fswwdt_apb_regs.sv
../rtl/fswwdt_clk_mon.sv
../rtl/fswwdt_core.sv
../rtl/fswwdt_top.sv
