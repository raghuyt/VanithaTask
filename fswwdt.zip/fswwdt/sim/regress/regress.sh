#!/usr/bin/env bash
#------------------------------------------------------------------------------
# regress.sh : run every (test, seed) from a list in parallel on the shared
# snapshot, classify results, merge coverage. Run from sim/.
#   ./regress/regress.sh [-j JOBS] [-l LIST] [-s BASE_SEED]
# Exit status is non-zero if any run fails (usable as a CI gate).
#------------------------------------------------------------------------------
set -u
JOBS=4; LIST=regress/tests.list; BASE_SEED=$RANDOM
while getopts "j:l:s:" o; do
  case $o in j) JOBS=$OPTARG ;; l) LIST=$OPTARG ;; s) BASE_SEED=$OPTARG ;; *) exit 2 ;; esac
done

WORK=$(pwd)/work
STAMP=$(date +%Y%m%d_%H%M%S)
RES=$WORK/regress_$STAMP
mkdir -p "$RES"
JOBFILE=$RES/jobs.txt; : > "$JOBFILE"

# 1. expand the list into one line per (test, seed)
n=0
while read -r t cnt; do
  [[ -z "$t" || "$t" == \#* ]] && continue
  for ((i = 0; i < cnt; i++)); do
    echo "$t $((BASE_SEED + n))" >> "$JOBFILE"; n=$((n + 1))
  done
done < "$LIST"
echo "regression: $n runs, $JOBS parallel, base seed $BASE_SEED, results in $RES"

# 2. one run = make sim; the log is classified, not just the exit code
run_one() {
  local t=$1 s=$2 log="$WORK/runs/${1}_${2}/sim.log" st
  make -s sim TEST="$t" SEED="$s" > /dev/null 2>&1
  if   [[ ! -f "$log" ]];                                        then st=NOLOG
  elif grep -q "UVM_FATAL @"            "$log";                  then st=FATAL
  elif grep -qE "^\*E|xmsim: \*E"       "$log";                  then st=SIMERR
  elif grep -q "\*\*\* TEST PASSED"     "$log";                  then st=PASS
  else st=FAIL; fi
  printf "%-6s %-34s %s\n" "$st" "$t" "$s"
}
export -f run_one; export WORK
xargs -P "$JOBS" -L 1 bash -c 'run_one "$0" "$1"' < "$JOBFILE" | tee "$RES/results.txt"

# 3. summary + coverage
pass=$(grep -c '^PASS' "$RES/results.txt")
total=$(wc -l < "$RES/results.txt")
echo "------------------------------------------------------------"
echo "PASSED $pass / $total"
grep -v '^PASS' "$RES/results.txt" | sort > "$RES/failures.txt"
[[ -s "$RES/failures.txt" ]] && { echo "failures:"; cat "$RES/failures.txt"; }
make -s cov_merge > "$RES/cov_merge.log" 2>&1 || echo "WARN: coverage merge failed (see cov_merge.log)"
[[ "$pass" -eq "$total" ]]
