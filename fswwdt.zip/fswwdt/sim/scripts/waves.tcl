# SimVision/SHM probe script, passed to xrun with -input.
# Verify command options against your Xcelium Tcl reference.
database -open waves -shm -into waves.shm -default
probe -create tb_top -depth all -all -database waves
# focused probes that are always useful when debugging this IP:
probe -create tb_top.u_dut.u_core -all -database waves
probe -create tb_top.u_dut.u_regs -all -database waves
run
exit
