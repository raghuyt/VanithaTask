# IMC batch script: merge all regression runs and write reports.
# Verify command options against your IMC release documentation.
merge cov_work/fswwdt/* -overwrite -out merged
load -run cov_work/fswwdt/merged
report -summary -metrics all                -out reports/cov_summary.rpt
report -detail  -metrics covergroup         -out reports/cov_functional.rpt
report -detail  -metrics block:expression:fsm:toggle -out reports/cov_code.rpt
exit
