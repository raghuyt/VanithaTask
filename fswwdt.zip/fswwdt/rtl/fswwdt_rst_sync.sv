//-----------------------------------------------------------------------------
// fswwdt_rst_sync.sv : asynchronous-assert / synchronous-deassert reset
// synchronizer. scan_mode_i bypasses it so ATPG controls reset directly.
// NOTE: the bypass mux should be a library reset/clock mux cell in a real flow.
//-----------------------------------------------------------------------------
module fswwdt_rst_sync #(
  parameter int unsigned STAGES = 2
) (
  input  logic clk_i,
  input  logic rst_ni,        // raw asynchronous reset, active low
  input  logic scan_mode_i,
  output logic rst_no         // synchronized reset, active low
);
  logic [STAGES-1:0] rst_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) rst_q <= '0;
    else         rst_q <= {rst_q[STAGES-2:0], 1'b1};
  end

  assign rst_no = scan_mode_i ? rst_ni : rst_q[STAGES-1];
endmodule : fswwdt_rst_sync
