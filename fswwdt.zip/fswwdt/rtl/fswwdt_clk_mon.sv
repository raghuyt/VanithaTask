//-----------------------------------------------------------------------------
// fswwdt_clk_mon.sv : watchdog-clock loss detector (runs on pclk).
// The core toggles a heartbeat every wdt_clk cycle; it is synchronized into
// pclk. If no heartbeat edge is seen for LIMIT pclk cycles while the
// watchdog is enabled, CLK_FAIL is raised and (if RST_EN) a reset request is
// asserted from THIS domain - the wdt domain cannot do it, its clock is dead.
//
// Requirement: f_pclk >= ~4 x f_wdt for the heartbeat to be sampled cleanly,
// and LIMIT must exceed the longest legitimate gap between heartbeat edges
// in pclk cycles (incl. ratio variation) with margin.
//-----------------------------------------------------------------------------
module fswwdt_clk_mon #(
  parameter int unsigned LIMIT = 64
) (
  input  logic clk_i,         // pclk
  input  logic rst_ni,
  input  logic en_i,          // CTRL.EN (pclk view)
  input  logic rst_en_i,      // CTRL.RST_EN
  input  logic hb_i,          // synchronized heartbeat
  output logic fail_evt_o,    // 1-cycle pulse
  output logic fail_o,        // sticky until reset
  output logic fail_rst_o     // sticky reset request until reset
);
  localparam int unsigned LW = $clog2(LIMIT + 1);

  logic          hb_q, fail_q, fail_rst_q, hb_edge;
  logic [LW-1:0] cnt_q;

  assign hb_edge    = hb_i ^ hb_q;
  assign fail_evt_o = en_i & ~fail_q & ~hb_edge & (cnt_q == LW'(LIMIT - 1));

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      hb_q       <= 1'b0;
      cnt_q      <= '0;
      fail_q     <= 1'b0;
      fail_rst_q <= 1'b0;
    end else begin
      hb_q <= hb_i;
      if (!en_i || hb_edge)           cnt_q <= '0;
      else if (cnt_q != LW'(LIMIT))   cnt_q <= cnt_q + 1'b1;
      if (fail_evt_o)                 fail_q     <= 1'b1;
      if (fail_evt_o && rst_en_i)     fail_rst_q <= 1'b1;
    end
  end

  assign fail_o     = fail_q;
  assign fail_rst_o = fail_rst_q;
endmodule : fswwdt_clk_mon
