//-----------------------------------------------------------------------------
// fswwdt_pkg.sv : shared constants, register map, types for the FSWWDT IP
//-----------------------------------------------------------------------------
package fswwdt_pkg;

  localparam int unsigned CNT_W  = 32;
  localparam int unsigned ADDR_W = 12;
  localparam int unsigned DATA_W = 32;

  // ---------------- Register map (byte addresses, word aligned) -------------
  localparam logic [ADDR_W-1:0] ADDR_CTRL      = 12'h000;
  localparam logic [ADDR_W-1:0] ADDR_TIMEOUT   = 12'h004;
  localparam logic [ADDR_W-1:0] ADDR_WINDOW    = 12'h008;
  localparam logic [ADDR_W-1:0] ADDR_EWI       = 12'h00C;
  localparam logic [ADDR_W-1:0] ADDR_KICK      = 12'h010;
  localparam logic [ADDR_W-1:0] ADDR_STATUS    = 12'h014;
  localparam logic [ADDR_W-1:0] ADDR_IRQ_EN    = 12'h018;
  localparam logic [ADDR_W-1:0] ADDR_COUNT     = 12'h01C;
  localparam logic [ADDR_W-1:0] ADDR_FAULT_INJ = 12'h020;
  localparam logic [ADDR_W-1:0] ADDR_ID        = 12'h024;

  // ---------------- Constants ----------------------------------------------
  localparam logic [DATA_W-1:0] KICK_KEY    = 32'hA5A5_5A5A;
  localparam logic [DATA_W-1:0] ID_VALUE    = 32'h4657_0100;   // "FW" v1.0
  localparam logic [CNT_W-1:0]  TIMEOUT_RST = 32'h0000_FFFF;

  // ---------------- CTRL bit positions -------------------------------------
  localparam int unsigned CTRL_EN      = 0;
  localparam int unsigned CTRL_WIN_EN  = 1;
  localparam int unsigned CTRL_RST_EN  = 2;
  localparam int unsigned CTRL_DBG_FRZ = 3;
  localparam int unsigned CTRL_LOCK    = 31;

  // ---------------- STATUS flag positions (W1C) / IRQ_EN bits ---------------
  localparam int unsigned FLG_EWI     = 0;
  localparam int unsigned FLG_TMO     = 1;
  localparam int unsigned FLG_EARLY   = 2;
  localparam int unsigned FLG_KEYERR  = 3;
  localparam int unsigned FLG_CNTERR  = 4;
  localparam int unsigned FLG_CLKFAIL = 5;
  localparam int unsigned NUM_FLAGS   = 6;

  // STATUS read-only fields
  localparam int unsigned STS_KICK_PEND = 8;
  localparam int unsigned STS_CFG_PEND  = 9;
  localparam int unsigned STS_LOCKED    = 10;
  localparam int unsigned STS_STATE_LSB = 12;   // [14:12]

  // ---------------- Core -> register-block events --------------------------
  localparam int unsigned EVT_EWI    = 0;
  localparam int unsigned EVT_TMO    = 1;
  localparam int unsigned EVT_EARLY  = 2;
  localparam int unsigned EVT_CNTERR = 3;
  localparam int unsigned NUM_EVT    = 4;

  // ---------------- Core FSM ------------------------------------------------
  typedef enum logic [2:0] {
    ST_DISABLED = 3'd0,   // counter held at 0
    ST_CLOSED   = 3'd1,   // counting, refresh NOT allowed (early window)
    ST_OPEN     = 3'd2,   // counting, refresh allowed
    ST_BITE     = 3'd3,   // reset request asserted for RST_LEN cycles
    ST_HALT     = 3'd4    // terminal, waits for system reset
  } wdt_state_e;

  // Configuration bundle transferred pclk -> wdt_clk as one atomic word
  typedef struct packed {
    logic             fi;       // fault-inject request (edge-detected in core)
    logic             dbg_frz;
    logic             rst_en;
    logic             win_en;
    logic             en;
    logic [CNT_W-1:0] ewi;
    logic [CNT_W-1:0] window;
    logic [CNT_W-1:0] timeout;
  } wdt_cfg_t;

  localparam int unsigned CFG_W  = $bits(wdt_cfg_t);
  localparam int unsigned SNAP_W = 3 + CNT_W;           // {state, count}

  // Legal configuration rule, shared by RTL and testbench predictor
  function automatic logic cfg_legal(input logic             win_en,
                                     input logic [CNT_W-1:0] timeout,
                                     input logic [CNT_W-1:0] window,
                                     input logic [CNT_W-1:0] ewi);
    return (timeout != '0) && (!win_en || (window < timeout)) && (ewi < timeout);
  endfunction

endpackage : fswwdt_pkg
