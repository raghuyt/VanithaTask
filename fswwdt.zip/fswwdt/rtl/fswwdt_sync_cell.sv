//-----------------------------------------------------------------------------
// fswwdt_sync_cell.sv : N-flop level synchronizer (single-bit CDC only).
// In a real flow replace the flops with the library's synchronizer cell so
// CDC tools (Conformal CDC / Jasper CDC) recognise it and STA applies MTBF
// aware constraints.
//-----------------------------------------------------------------------------
module fswwdt_sync_cell #(
  parameter int unsigned STAGES  = 2,
  parameter logic        RST_VAL = 1'b0
) (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic d_i,
  output logic q_o
);
  logic [STAGES-1:0] sync_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) sync_q <= {STAGES{RST_VAL}};
    else         sync_q <= {sync_q[STAGES-2:0], d_i};
  end

  assign q_o = sync_q[STAGES-1];

`ifdef FSWWDT_ASSERT_ON
  initial assert (STAGES >= 2) else $fatal(1, "fswwdt_sync_cell: STAGES must be >= 2");
`endif
endmodule : fswwdt_sync_cell
