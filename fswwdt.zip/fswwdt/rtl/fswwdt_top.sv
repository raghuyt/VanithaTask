//-----------------------------------------------------------------------------
// fswwdt_top.sv : Fail-Safe Window Watchdog Timer - top level
//
//  pclk domain    : APB registers, flags, IRQ, clock monitor
//  wdt_clk domain : counter/FSM core (independent, always-on clock)
//  CDC            : cfg bundle (hs_sync), kick (hs_sync), events (evt_sync),
//                   count/state snapshot (hs_sync), dbg_halt & heartbeat
//                   (2-flop sync cells)
//  Reset          : single async presetn, synchronized separately per domain
//-----------------------------------------------------------------------------
module fswwdt_top
  import fswwdt_pkg::*;
#(
  parameter int unsigned RST_LEN      = 16,
  parameter int unsigned CLKMON_LIMIT = 64,
  parameter int unsigned SYNC_STAGES  = 2
) (
  // APB3 slave (pclk domain)
  input  logic              pclk,
  input  logic              presetn,
  input  logic              psel,
  input  logic              penable,
  input  logic              pwrite,
  input  logic [ADDR_W-1:0] paddr,
  input  logic [DATA_W-1:0] pwdata,
  output logic [DATA_W-1:0] prdata,
  output logic              pready,
  output logic              pslverr,
  // independent watchdog clock
  input  logic              wdt_clk,
  // misc
  input  logic              scan_mode_i,
  input  logic              dbg_halt_i,     // CPU halted in debug (async)
  // outputs
  output logic              wdt_irq_o,      // level, pclk domain
  output logic              wdt_rst_req_o   // to SoC reset controller (async-sampled)
);

  // ---------------- resets ---------------------------------------------------
  logic prst_n, wrst_n;

  fswwdt_rst_sync #(.STAGES(SYNC_STAGES)) u_prst_sync (
    .clk_i(pclk),    .rst_ni(presetn), .scan_mode_i(scan_mode_i), .rst_no(prst_n));
  fswwdt_rst_sync #(.STAGES(SYNC_STAGES)) u_wrst_sync (
    .clk_i(wdt_clk), .rst_ni(presetn), .scan_mode_i(scan_mode_i), .rst_no(wrst_n));

  // ---------------- internal signals ----------------------------------------
  wdt_cfg_t           cfg_p, cfg_w;
  logic               cfg_send, cfg_busy, cfg_vld_w;
  logic               kick_send, kick_bad_p, kick_busy, kick_vld_w, kick_bad_w;
  logic               kick_good_core, kick_bad_core;
  logic [NUM_EVT-1:0] evt_w, evt_p;
  logic               evt_pend_w;
  logic [SNAP_W-1:0]  snap_w, snap_p;
  logic               snap_busy, snap_vld;
  wdt_state_e         state_w;
  logic [CNT_W-1:0]   cnt_w;
  logic               hb_w, hb_p, dbg_halt_w;
  logic               ctrl_en_p, rst_en_p;
  logic               clkfail_evt_p, clkfail_p, clkfail_rst_p, core_rst_req_w;
  logic [CFG_W-1:0]   cfg_w_bits;

  // ---------------- register block (pclk) ------------------------------------
  fswwdt_apb_regs u_regs (
    .clk_i        (pclk),         .rst_ni     (prst_n),
    .psel_i       (psel),         .penable_i  (penable),
    .pwrite_i     (pwrite),       .paddr_i    (paddr),
    .pwdata_i     (pwdata),       .prdata_o   (prdata),
    .pready_o     (pready),       .pslverr_o  (pslverr),
    .cfg_o        (cfg_p),        .cfg_send_o (cfg_send),  .cfg_busy_i (cfg_busy),
    .kick_send_o  (kick_send),    .kick_bad_o (kick_bad_p),.kick_busy_i(kick_busy),
    .core_evt_i   (evt_p),        .clkfail_evt_i(clkfail_evt_p),
    .snap_i       (snap_p),
    .ctrl_en_o    (ctrl_en_p),    .rst_en_o   (rst_en_p),
    .irq_o        (wdt_irq_o));

  // ---------------- CDC: config pclk -> wdt_clk -------------------------------
  fswwdt_hs_sync #(.W(CFG_W), .STAGES(SYNC_STAGES)) u_cfg_sync (
    .src_clk_i(pclk),    .src_rst_ni(prst_n), .src_req_i(cfg_send),
    .src_data_i(cfg_p),  .src_busy_o(cfg_busy),
    .dst_clk_i(wdt_clk), .dst_rst_ni(wrst_n), .dst_vld_o(cfg_vld_w),
    .dst_data_o(cfg_w_bits));
  assign cfg_w = wdt_cfg_t'(cfg_w_bits);

  // ---------------- CDC: kick pclk -> wdt_clk ---------------------------------
  fswwdt_hs_sync #(.W(1), .STAGES(SYNC_STAGES)) u_kick_sync (
    .src_clk_i(pclk),    .src_rst_ni(prst_n), .src_req_i(kick_send),
    .src_data_i(kick_bad_p), .src_busy_o(kick_busy),
    .dst_clk_i(wdt_clk), .dst_rst_ni(wrst_n), .dst_vld_o(kick_vld_w),
    .dst_data_o(kick_bad_w));
  assign kick_good_core = kick_vld_w & ~kick_bad_w;
  assign kick_bad_core  = kick_vld_w &  kick_bad_w;

  // ---------------- CDC: events wdt_clk -> pclk --------------------------------
  fswwdt_evt_sync #(.W(NUM_EVT), .STAGES(SYNC_STAGES)) u_evt_sync (
    .src_clk_i(wdt_clk), .src_rst_ni(wrst_n), .src_evt_i(evt_w), .src_pend_o(evt_pend_w),
    .dst_clk_i(pclk),    .dst_rst_ni(prst_n), .dst_evt_o(evt_p));

  // ---------------- CDC: state/count snapshot wdt_clk -> pclk ------------------
  assign snap_w = {state_w, cnt_w};
  fswwdt_hs_sync #(.W(SNAP_W), .STAGES(SYNC_STAGES)) u_snap_sync (
    .src_clk_i(wdt_clk), .src_rst_ni(wrst_n), .src_req_i(1'b1),
    .src_data_i(snap_w), .src_busy_o(snap_busy),
    .dst_clk_i(pclk),    .dst_rst_ni(prst_n), .dst_vld_o(snap_vld),
    .dst_data_o(snap_p));

  // ---------------- CDC: single-bit levels ----------------------------------
  fswwdt_sync_cell #(.STAGES(SYNC_STAGES)) u_dbg_sync (
    .clk_i(wdt_clk), .rst_ni(wrst_n), .d_i(dbg_halt_i), .q_o(dbg_halt_w));
  fswwdt_sync_cell #(.STAGES(SYNC_STAGES)) u_hb_sync (
    .clk_i(pclk),    .rst_ni(prst_n), .d_i(hb_w),       .q_o(hb_p));

  // ---------------- watchdog clock monitor (pclk) -----------------------------
  fswwdt_clk_mon #(.LIMIT(CLKMON_LIMIT)) u_clk_mon (
    .clk_i(pclk), .rst_ni(prst_n), .en_i(ctrl_en_p), .rst_en_i(rst_en_p),
    .hb_i(hb_p),  .fail_evt_o(clkfail_evt_p), .fail_o(clkfail_p),
    .fail_rst_o(clkfail_rst_p));

  // ---------------- watchdog core (wdt_clk) ---------------------------------
  fswwdt_core #(.RST_LEN(RST_LEN)) u_core (
    .clk_i(wdt_clk), .rst_ni(wrst_n), .cfg_i(cfg_w),
    .kick_good_i(kick_good_core), .kick_bad_i(kick_bad_core),
    .dbg_halt_i(dbg_halt_w),
    .state_o(state_w), .cnt_o(cnt_w), .evt_o(evt_w),
    .rst_req_o(core_rst_req_w), .hb_o(hb_w));

  // ---------------- reset request -------------------------------------------
  // OR of two flop outputs from different domains. The SoC reset controller
  // must treat this as an asynchronous request and synchronize it.
  assign wdt_rst_req_o = core_rst_req_w | clkfail_rst_p;

endmodule : fswwdt_top
