//-----------------------------------------------------------------------------
// fswwdt_hs_sync.sv : two-phase (toggle) request/acknowledge bus synchronizer.
//
//  * src_req_i is accepted only when !src_busy_o. Data is captured into a
//    source holding register and held stable until the acknowledge returns,
//    so the destination can sample the multi-bit bus without per-bit skew.
//  * dst_vld_o pulses for one dst clock when dst_data_o has been updated.
//  * Only the single-bit toggles cross domains through synchronizer cells;
//    the data bus is a "qualified" (mux-recirculation style) crossing.
//-----------------------------------------------------------------------------
module fswwdt_hs_sync #(
  parameter int unsigned W      = 32,
  parameter int unsigned STAGES = 2
) (
  // source domain
  input  logic         src_clk_i,
  input  logic         src_rst_ni,
  input  logic         src_req_i,
  input  logic [W-1:0] src_data_i,
  output logic         src_busy_o,
  // destination domain
  input  logic         dst_clk_i,
  input  logic         dst_rst_ni,
  output logic         dst_vld_o,
  output logic [W-1:0] dst_data_o
);
  logic         src_tgl_q, src_ack_sync;
  logic [W-1:0] src_data_q;
  logic         dst_tgl_sync, dst_tgl_q, dst_vld_q;
  logic [W-1:0] dst_data_q;

  // ---------------- source side --------------------------------------------
  assign src_busy_o = src_tgl_q ^ src_ack_sync;

  always_ff @(posedge src_clk_i or negedge src_rst_ni) begin
    if (!src_rst_ni) begin
      src_tgl_q  <= 1'b0;
      src_data_q <= '0;
    end else if (src_req_i && !src_busy_o) begin
      src_tgl_q  <= ~src_tgl_q;
      src_data_q <= src_data_i;
    end
  end

  fswwdt_sync_cell #(.STAGES(STAGES)) u_req_sync (
    .clk_i(dst_clk_i), .rst_ni(dst_rst_ni), .d_i(src_tgl_q), .q_o(dst_tgl_sync));

  // ---------------- destination side ---------------------------------------
  always_ff @(posedge dst_clk_i or negedge dst_rst_ni) begin
    if (!dst_rst_ni) begin
      dst_tgl_q  <= 1'b0;
      dst_vld_q  <= 1'b0;
      dst_data_q <= '0;
    end else begin
      dst_tgl_q <= dst_tgl_sync;
      dst_vld_q <= dst_tgl_sync ^ dst_tgl_q;
      if (dst_tgl_sync ^ dst_tgl_q) dst_data_q <= src_data_q;  // CDC: qualified by toggle
    end
  end

  fswwdt_sync_cell #(.STAGES(STAGES)) u_ack_sync (
    .clk_i(src_clk_i), .rst_ni(src_rst_ni), .d_i(dst_tgl_q), .q_o(src_ack_sync));

  assign dst_vld_o  = dst_vld_q;
  assign dst_data_o = dst_data_q;

`ifdef FSWWDT_ASSERT_ON
  // Source holding register must not change while a transfer is in flight.
  a_src_data_stable: assert property (@(posedge src_clk_i) disable iff (!src_rst_ni)
                       src_busy_o |=> $stable(src_data_q));
`endif
endmodule : fswwdt_hs_sync
