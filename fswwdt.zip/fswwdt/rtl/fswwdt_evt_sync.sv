//-----------------------------------------------------------------------------
// fswwdt_evt_sync.sv : multi-bit event (pulse) synchronizer with coalescing.
// Events arriving while a transfer is in flight are OR-accumulated and sent
// in the next transfer, so no event is ever lost (it may be merged with a
// later event of the same type - acceptable because destination flags are
// sticky).
//-----------------------------------------------------------------------------
module fswwdt_evt_sync #(
  parameter int unsigned W      = 4,
  parameter int unsigned STAGES = 2
) (
  input  logic         src_clk_i,
  input  logic         src_rst_ni,
  input  logic [W-1:0] src_evt_i,
  output logic         src_pend_o,
  input  logic         dst_clk_i,
  input  logic         dst_rst_ni,
  output logic [W-1:0] dst_evt_o
);
  logic [W-1:0] pend_q, dst_data;
  logic         busy, launch, dst_vld;

  assign launch = (|pend_q) && !busy;

  always_ff @(posedge src_clk_i or negedge src_rst_ni) begin
    if (!src_rst_ni) pend_q <= '0;
    else             pend_q <= (launch ? '0 : pend_q) | src_evt_i;
  end

  fswwdt_hs_sync #(.W(W), .STAGES(STAGES)) u_hs (
    .src_clk_i (src_clk_i), .src_rst_ni(src_rst_ni),
    .src_req_i (launch),    .src_data_i(pend_q), .src_busy_o(busy),
    .dst_clk_i (dst_clk_i), .dst_rst_ni(dst_rst_ni),
    .dst_vld_o (dst_vld),   .dst_data_o(dst_data));

  assign dst_evt_o  = dst_vld ? dst_data : '0;
  assign src_pend_o = (|pend_q) || busy;
endmodule : fswwdt_evt_sync
