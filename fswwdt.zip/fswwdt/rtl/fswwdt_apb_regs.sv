//-----------------------------------------------------------------------------
// fswwdt_apb_regs.sv : APB3 slave register block (pclk domain)
//
//  * Zero-wait-state APB3 (PREADY tied high), writes committed in ACCESS phase.
//  * PSLVERR on: unmapped/misaligned address, write to RO register, write to a
//    locked register, config write while EN=1, enabling with an illegal
//    configuration, changing WIN_EN while running, config write while a
//    previous config transfer is still pending (CFG_PEND), kick write while
//    the previous kick is still in flight (KICK_PEND).
//  * Every accepted config write is delivered to the watchdog domain as ONE
//    atomic bundle; blocking writes while CFG_PEND guarantees the core sees
//    every configuration in order (no coalescing hazards).
//-----------------------------------------------------------------------------
module fswwdt_apb_regs
  import fswwdt_pkg::*;
(
  input  logic                clk_i,
  input  logic                rst_ni,
  // APB3 slave
  input  logic                psel_i,
  input  logic                penable_i,
  input  logic                pwrite_i,
  input  logic [ADDR_W-1:0]   paddr_i,
  input  logic [DATA_W-1:0]   pwdata_i,
  output logic [DATA_W-1:0]   prdata_o,
  output logic                pready_o,
  output logic                pslverr_o,
  // configuration channel to the watchdog domain
  output wdt_cfg_t            cfg_o,
  output logic                cfg_send_o,
  input  logic                cfg_busy_i,
  // kick channel to the watchdog domain
  output logic                kick_send_o,
  output logic                kick_bad_o,
  input  logic                kick_busy_i,
  // events / status from the watchdog domain (already synchronized)
  input  logic [NUM_EVT-1:0]  core_evt_i,
  input  logic                clkfail_evt_i,
  input  logic [SNAP_W-1:0]   snap_i,
  // local outputs
  output logic                ctrl_en_o,
  output logic                rst_en_o,
  output logic                irq_o
);

  // ---------------- registers ----------------------------------------------
  logic                 en_q, win_en_q, rst_en_q, dbg_frz_q, lock_q, fi_q;
  logic [CNT_W-1:0]     timeout_q, window_q, ewi_q;
  logic [NUM_FLAGS-1:0] flags_q, irq_en_q;
  logic                 cfg_dirty_q, irq_q;

  // ---------------- APB decode ----------------------------------------------
  logic acc, wr_acc, rd_acc, wr_err, rd_err, wr_ok, cfg_pend, wr_cfg;

  assign acc      = psel_i & penable_i;
  assign wr_acc   = acc &  pwrite_i;
  assign rd_acc   = acc & ~pwrite_i;
  assign cfg_pend = cfg_dirty_q | cfg_busy_i;

  always_comb begin
    wr_err = 1'b0;
    case (paddr_i)
      ADDR_CTRL:      wr_err = lock_q | cfg_pend
                             | (pwdata_i[CTRL_EN] &
                                ~cfg_legal(pwdata_i[CTRL_WIN_EN], timeout_q, window_q, ewi_q))
                             | (en_q & (pwdata_i[CTRL_WIN_EN] != win_en_q));
      ADDR_TIMEOUT,
      ADDR_WINDOW,
      ADDR_EWI:       wr_err = lock_q | en_q | cfg_pend;
      ADDR_FAULT_INJ: wr_err = lock_q | cfg_pend;
      ADDR_KICK:      wr_err = kick_busy_i;
      ADDR_STATUS,
      ADDR_IRQ_EN:    wr_err = 1'b0;
      default:        wr_err = 1'b1;          // COUNT/ID are RO, rest unmapped
    endcase
  end

  always_comb begin
    case (paddr_i)
      ADDR_CTRL, ADDR_TIMEOUT, ADDR_WINDOW, ADDR_EWI, ADDR_KICK, ADDR_STATUS,
      ADDR_IRQ_EN, ADDR_COUNT, ADDR_FAULT_INJ, ADDR_ID: rd_err = 1'b0;
      default:                                          rd_err = 1'b1;
    endcase
  end

  assign wr_ok  = wr_acc & ~wr_err;
  assign wr_cfg = wr_ok & ((paddr_i == ADDR_CTRL)    | (paddr_i == ADDR_TIMEOUT) |
                           (paddr_i == ADDR_WINDOW)  | (paddr_i == ADDR_EWI)     |
                           (paddr_i == ADDR_FAULT_INJ));

  // ---------------- configuration registers --------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      en_q      <= 1'b0;  win_en_q <= 1'b0;  rst_en_q <= 1'b0;
      dbg_frz_q <= 1'b0;  lock_q   <= 1'b0;  fi_q     <= 1'b0;
      timeout_q <= TIMEOUT_RST;
      window_q  <= '0;
      ewi_q     <= '0;
      irq_en_q  <= '0;
    end else if (wr_ok) begin
      case (paddr_i)
        ADDR_CTRL: begin
          en_q      <= pwdata_i[CTRL_EN];
          win_en_q  <= pwdata_i[CTRL_WIN_EN];
          rst_en_q  <= pwdata_i[CTRL_RST_EN];
          dbg_frz_q <= pwdata_i[CTRL_DBG_FRZ];
          lock_q    <= lock_q | pwdata_i[CTRL_LOCK];     // write-1-to-set, sticky
        end
        ADDR_TIMEOUT:   timeout_q <= pwdata_i;
        ADDR_WINDOW:    window_q  <= pwdata_i;
        ADDR_EWI:       ewi_q     <= pwdata_i;
        ADDR_IRQ_EN:    irq_en_q  <= pwdata_i[NUM_FLAGS-1:0];
        ADDR_FAULT_INJ: fi_q      <= pwdata_i[0];
        default: ;
      endcase
    end
  end

  // ---------------- config transfer request ---------------------------------
  assign cfg_send_o = cfg_dirty_q & ~cfg_busy_i;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) cfg_dirty_q <= 1'b0;
    else         cfg_dirty_q <= (cfg_dirty_q & ~cfg_send_o) | wr_cfg;
  end

  always_comb begin
    cfg_o         = '0;
    cfg_o.fi      = fi_q;
    cfg_o.dbg_frz = dbg_frz_q;
    cfg_o.rst_en  = rst_en_q;
    cfg_o.win_en  = win_en_q;
    cfg_o.en      = en_q;
    cfg_o.ewi     = ewi_q;
    cfg_o.window  = window_q;
    cfg_o.timeout = timeout_q;
  end

  // ---------------- kick -----------------------------------------------------
  assign kick_send_o = wr_ok & (paddr_i == ADDR_KICK);
  assign kick_bad_o  = (pwdata_i != KICK_KEY);

  // ---------------- sticky status flags (set has priority over W1C) --------
  logic [NUM_FLAGS-1:0] flag_set, flag_clr;

  always_comb begin
    flag_set              = '0;
    flag_set[FLG_EWI]     = core_evt_i[EVT_EWI];
    flag_set[FLG_TMO]     = core_evt_i[EVT_TMO];
    flag_set[FLG_EARLY]   = core_evt_i[EVT_EARLY];
    flag_set[FLG_CNTERR]  = core_evt_i[EVT_CNTERR];
    flag_set[FLG_KEYERR]  = kick_send_o & kick_bad_o;
    flag_set[FLG_CLKFAIL] = clkfail_evt_i;
    flag_clr = (wr_ok && (paddr_i == ADDR_STATUS)) ? pwdata_i[NUM_FLAGS-1:0] : '0;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      flags_q <= '0;
      irq_q   <= 1'b0;
    end else begin
      flags_q <= (flags_q & ~flag_clr) | flag_set;
      irq_q   <= |(flags_q & irq_en_q);
    end
  end

  // ---------------- read mux (combinational, valid in ACCESS phase) --------
  always_comb begin
    prdata_o = '0;
    if (rd_acc) begin
      case (paddr_i)
        ADDR_CTRL: begin
          prdata_o[CTRL_EN]      = en_q;
          prdata_o[CTRL_WIN_EN]  = win_en_q;
          prdata_o[CTRL_RST_EN]  = rst_en_q;
          prdata_o[CTRL_DBG_FRZ] = dbg_frz_q;
          prdata_o[CTRL_LOCK]    = lock_q;
        end
        ADDR_TIMEOUT:   prdata_o = timeout_q;
        ADDR_WINDOW:    prdata_o = window_q;
        ADDR_EWI:       prdata_o = ewi_q;
        ADDR_STATUS: begin
          prdata_o[NUM_FLAGS-1:0]         = flags_q;
          prdata_o[STS_KICK_PEND]         = kick_busy_i;
          prdata_o[STS_CFG_PEND]          = cfg_pend;
          prdata_o[STS_LOCKED]            = lock_q;
          prdata_o[STS_STATE_LSB +: 3]    = snap_i[SNAP_W-1 -: 3];
        end
        ADDR_IRQ_EN:    prdata_o[NUM_FLAGS-1:0] = irq_en_q;
        ADDR_COUNT:     prdata_o = snap_i[CNT_W-1:0];
        ADDR_FAULT_INJ: prdata_o[0] = fi_q;
        ADDR_ID:        prdata_o = ID_VALUE;
        default:        prdata_o = '0;       // includes KICK (write-only)
      endcase
    end
  end

  assign pready_o  = 1'b1;
  assign pslverr_o = acc & (pwrite_i ? wr_err : rd_err);
  assign ctrl_en_o = en_q;
  assign rst_en_o  = rst_en_q;
  assign irq_o     = irq_q;

endmodule : fswwdt_apb_regs
