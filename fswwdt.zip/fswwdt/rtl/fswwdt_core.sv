//-----------------------------------------------------------------------------
// fswwdt_core.sv : window watchdog engine (wdt_clk domain)
//
//  Counter counts UP from 0. With the window enabled:
//      0 ............ WINDOW-1 | WINDOW ............ TIMEOUT-1 | TIMEOUT
//      <---- CLOSED: kick = EARLY fault ---><--- OPEN: kick OK --->  timeout fault
//  EWI (early-warning) event fires when the counter reaches EWI (0 = off).
//
//  Faults : timeout, early kick, bad key, redundant-counter mismatch.
//           RST_EN=1 -> BITE (reset request for RST_LEN cycles) -> HALT
//           RST_EN=0 -> event/interrupt only, period restarts.
//  Safety : a shadow counter holds the bitwise inverse of the main counter;
//           any mismatch is a fault. Illegal FSM codes recover to BITE
//           (fail-safe). Fault has priority over a simultaneous kick/disable.
//  NOTE   : synthesis will try to merge the shadow counter and remove the
//           illegal-state recovery; they must be preserved with tool
//           directives in the synthesis flow (see docs).
//-----------------------------------------------------------------------------
module fswwdt_core
  import fswwdt_pkg::*;
#(
  parameter int unsigned RST_LEN = 16            // >= 2
) (
  input  logic               clk_i,
  input  logic               rst_ni,
  input  wdt_cfg_t           cfg_i,              // stable, synchronized config
  input  logic               kick_good_i,        // 1-cycle pulses
  input  logic               kick_bad_i,
  input  logic               dbg_halt_i,         // synchronized
  output wdt_state_e         state_o,
  output logic [CNT_W-1:0]   cnt_o,
  output logic [NUM_EVT-1:0] evt_o,              // 1-cycle event pulses
  output logic               rst_req_o,
  output logic               hb_o                // heartbeat for clock monitor
);
  localparam int unsigned BW = $clog2(RST_LEN + 1);

  wdt_state_e         state_q, state_d, restart_st;
  logic [CNT_W-1:0]   cnt_q, cnt_d, cnt_n_q, cnt_n_d, cnt_inc;
  logic [BW-1:0]      bite_q, bite_d;
  logic               fi_q, fi_rise, rst_req_q, hb_q;
  logic [NUM_EVT-1:0] evt_q;
  logic               running, freeze, tick, cnt_err, tmo_hit, ewi_hit;
  logic               early_kick, key_flt, kick_ok, fault;

  // ---------------- datapath / condition decode -----------------------------
  assign running    = (state_q == ST_CLOSED) || (state_q == ST_OPEN);
  assign freeze     = cfg_i.dbg_frz & dbg_halt_i;
  assign tick       = running & ~freeze;
  assign cnt_inc    = cnt_q + 1'b1;
  assign cnt_err    = running & (cnt_q != ~cnt_n_q);
  assign tmo_hit    = tick & (cnt_inc == cfg_i.timeout);
  assign ewi_hit    = tick & (cfg_i.ewi != '0) & (cnt_inc == cfg_i.ewi);
  assign early_kick = running & kick_good_i & (state_q == ST_CLOSED);
  assign key_flt    = running & kick_bad_i;
  assign kick_ok    = running & kick_good_i & (state_q == ST_OPEN);
  assign fault      = cnt_err | tmo_hit | early_kick | key_flt;
  assign fi_rise    = cfg_i.fi & ~fi_q;
  assign restart_st = (!cfg_i.win_en || (cfg_i.window == '0)) ? ST_OPEN : ST_CLOSED;

  // ---------------- next-state logic ----------------------------------------
  always_comb begin
    state_d = state_q;
    cnt_d   = cnt_q;
    cnt_n_d = cnt_n_q;
    bite_d  = bite_q;

    case (state_q)
      ST_DISABLED: begin
        if (cfg_i.en) begin
          state_d = restart_st;
          cnt_d   = '0;
          cnt_n_d = '1;
        end
      end

      ST_CLOSED, ST_OPEN: begin
        if (fault) begin                               // priority 1: fault
          cnt_d   = '0;
          cnt_n_d = '1;
          if (cfg_i.rst_en) begin
            state_d = ST_BITE;
            bite_d  = BW'(RST_LEN - 1);
          end else begin
            state_d = restart_st;
          end
        end else if (!cfg_i.en) begin                  // priority 2: disable
          state_d = ST_DISABLED;
          cnt_d   = '0;
          cnt_n_d = '1;
        end else if (kick_ok) begin                    // priority 3: refresh
          state_d = restart_st;
          cnt_d   = '0;
          cnt_n_d = '1;
        end else if (tick) begin                       // priority 4: count
          cnt_d   = cnt_inc;
          cnt_n_d = ~cnt_inc;
          if ((state_q == ST_CLOSED) && (cnt_inc >= cfg_i.window)) state_d = ST_OPEN;
        end
        // fault injection: corrupt the shadow counter once (test/diagnostic)
        if (fi_rise && ((state_d == ST_CLOSED) || (state_d == ST_OPEN)))
          cnt_n_d[0] = ~cnt_n_d[0];
      end

      ST_BITE: begin
        if (bite_q == '0) state_d = ST_HALT;
        else              bite_d  = bite_q - 1'b1;
      end

      ST_HALT: ;                                       // wait for system reset

      default: begin                                   // illegal code -> fail safe
        state_d = ST_BITE;
        bite_d  = BW'(RST_LEN - 1);
        cnt_d   = '0;
        cnt_n_d = '1;
      end
    endcase
  end

  // ---------------- state / output registers --------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q   <= ST_DISABLED;
      cnt_q     <= '0;
      cnt_n_q   <= '1;
      bite_q    <= '0;
      fi_q      <= 1'b0;
      rst_req_q <= 1'b0;
      evt_q     <= '0;
      hb_q      <= 1'b0;
    end else begin
      state_q   <= state_d;
      cnt_q     <= cnt_d;
      cnt_n_q   <= cnt_n_d;
      bite_q    <= bite_d;
      fi_q      <= cfg_i.fi;
      rst_req_q <= (state_d == ST_BITE);
      evt_q[EVT_EWI]    <= ewi_hit;
      evt_q[EVT_TMO]    <= tmo_hit;
      evt_q[EVT_EARLY]  <= early_kick;
      evt_q[EVT_CNTERR] <= cnt_err;
      hb_q      <= ~hb_q;
    end
  end

  assign state_o   = state_q;
  assign cnt_o     = cnt_q;
  assign evt_o     = evt_q;
  assign rst_req_o = rst_req_q;
  assign hb_o      = hb_q;

endmodule : fswwdt_core
